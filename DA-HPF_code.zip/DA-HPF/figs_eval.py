"""Robustness, unseen attack-class, leakage audit, CV distributions, CD diagrams, latency, ablation."""
import numpy as np
from common import *
plt = style()

DS = {"cic": "CICIDS2017", "unsw": "UNSW-NB15"}
ALPHA = {"cic": 1e-3, "unsw": 1e-2}
MS = {"CREF (proposed)": (C["verm"], "D", "-"), "XGBoost": (C["blue"], "o", "--"), "Soft voting": (C["green"], "s", ":")}


def nice(c): return {"DDOS": "DDoS", "PORTSCAN": "PortScan", "DOS": "DoS"}.get(c, c.title())


# ---------------------------------------------------------------- robustness
if all(os.path.exists(os.path.join(RES, f"robust_{t}.json")) for t in DS):
    rob = {t: load_json(f"robust_{t}.json") for t in DS}
    fig, axs = plt.subplots(2, 4, figsize=(7.0, 3.9))
    for j, t in enumerate(DS):
        r = rob[t]
        for c_, (sec, xlabel) in enumerate([("noise", r"Gaussian noise $\sigma$ (z-units)"), ("missing", "fraction of features missing")]):
            xs = sorted(float(k) for k in r[sec])
            for m, (col, mk, ls) in MS.items():
                axs[j, 2 * c_].plot(xs, [r[sec][str(x) if str(x) in r[sec] else repr(x)][m]["macro_f1"] * 100 for x in xs],
                                    ls=ls, marker=mk, color=col, ms=3, label=m)
                axs[j, 2 * c_ + 1].plot(xs, [max(r[sec][str(x)][m]["far"], 1e-5) * 100 for x in xs], ls=ls, marker=mk, color=col, ms=3)
            axs[j, 2 * c_ + 1].axhline(ALPHA[t] * 100, color="k", lw=0.7, ls=":")
            axs[j, 2 * c_ + 1].set_yscale("log")
            axs[j, 2 * c_].set_ylabel("Macro-F1 (%)", fontsize=7); axs[j, 2 * c_ + 1].set_ylabel("benign FAR (%)", fontsize=7)
            for a in axs[j, 2 * c_:2 * c_ + 2]:
                a.set_xlabel(xlabel, fontsize=6.5); a.tick_params(labelsize=6); a.grid(True)
            axs[j, 2 * c_].set_title(f"{DS[t]}", fontsize=7.5, loc="left")
    axs[0, 0].legend(fontsize=5.8)
    fig.tight_layout(); savefig(fig, "N22_robustness_noise_missing")
    fig, axs = plt.subplots(1, 2, figsize=(7.0, 2.4))
    for j, t in enumerate(DS):
        r = rob[t]["prevalence"]; xs = sorted(float(k) for k in r)
        for m, (col, mk, ls) in MS.items():
            axs[j].plot(xs, [r[str(x)][m]["precision"] * 100 for x in xs], ls=ls, marker=mk, color=col, ms=3, label=m)
        axs[j].set_xscale("log"); axs[j].set_xlabel("attack prevalence in traffic"); axs[j].set_ylabel("alarm precision (%)")
        axs[j].set_title(f"({'ab'[j]}) {DS[t]}", fontsize=7.5); axs[j].grid(True); axs[j].legend(fontsize=6)
    fig.tight_layout(); savefig(fig, "N23_precision_vs_prevalence")

# ---------------------------------------------------------------- unseen attack-class
rows = []
for t, cl in [("cic", ["BOT", "PORTSCAN", "DDOS"]), ("unsw", ["WORMS", "SHELLCODE", "BACKDOOR", "DOS"])]:
    for c in cl:
        f = os.path.join(RES, f"core_{t}_ex_{c}.json")
        if not os.path.exists(f): continue
        d = load_json(f"core_{t}_ex_{c}.json"); a = str(ALPHA[t])
        base = load_json(f"core_{t}.json")["at_alpha"][a]
        rows.append((t, c, {m: d["at_alpha"][a][m]["per_class"][c] for m in MS},
                     {m: base[m]["per_class"][c] for m in MS},
                     {m: d["at_alpha"][a][m]["far"] for m in MS},
                     {m: d["at_alpha"]["0.01"][m]["per_class"][c] for m in MS}))
if rows:
    fig, axs = plt.subplots(1, 2, figsize=(7.0, 2.7), gridspec_kw=dict(width_ratios=[1.5, 1]))
    x = np.arange(len(rows)); w = 0.26
    for q, (m, (col, _, _)) in enumerate(MS.items()):
        axs[0].bar(x + (q - 1) * w, [r[2][m] * 100 for r in rows], w, color=col, label=f"{m}: class unseen")
        axs[0].scatter(x + (q - 1) * w, [r[3][m] * 100 for r in rows], marker="_", s=60, color="k", zorder=3)
    axs[0].scatter([], [], marker="_", s=60, color="k", label="same method, class seen in training")
    axs[0].set_xticks(x); axs[0].set_xticklabels([f"{'CIC' if r[0]=='cic' else 'UNSW'}\n{nice(r[1])}" for r in rows], fontsize=6.5)
    axs[0].set_ylabel("recall of held-out class (%)"); axs[0].set_ylim(0, 135)
    axs[0].legend(fontsize=5.6, loc="upper center", ncol=2, bbox_to_anchor=(0.5, 1.0))
    axs[0].set_title("(a) leave-one-attack-class-out", fontsize=7.5)
    for q, (m, (col, _, _)) in enumerate(MS.items()):
        axs[1].bar(x + (q - 1) * w, [r[5][m] * 100 for r in rows], w, color=col)
    axs[1].set_xticks(x); axs[1].set_xticklabels([f"{nice(r[1])}" for r in rows], fontsize=6, rotation=30)
    axs[1].set_ylabel("held-out recall (%) at $\\alpha$=0.01 (MONITOR)"); axs[1].set_title("(b) looser MONITOR level", fontsize=7.5)
    fig.tight_layout(); savefig(fig, "N24_unseen_attack_class")
    save_json([dict(ds=r[0], cls=r[1], unseen=r[2], seen=r[3], far=r[4], unseen_monitor=r[5]) for r in rows], "unseen_summary.json")

# ---------------------------------------------------------------- leakage audit
cfg = [("cic", "random split"), ("cic_temporal", "temporal (row-order) split"), ("cic_nodport", "random, no Destination Port")]
if all(os.path.exists(os.path.join(RES, f"core_{c}.json")) for c, _ in cfg):
    fig, axs = plt.subplots(1, 4, figsize=(7.0, 2.4))
    mets = [("macro_f1", "Macro-F1 (%)"), ("mcc", "MCC (%)"), ("rec", "TPR (%)"), ("far", "FAR (%)")]
    for i, (k, lab) in enumerate(mets):
        ax = axs[i]; w = 0.26
        for q, (m, (col, _, _)) in enumerate(MS.items()):
            v = [load_json(f"core_{c}.json")["at_alpha"]["0.001"][m][k] * 100 for c, _ in cfg]
            ax.bar(np.arange(3) + (q - 1) * w, v, w, color=col, label=m)
        ax.set_xticks(range(3)); ax.set_xticklabels(["random", "temporal", "no DstPort"], fontsize=6.3, rotation=20)
        ax.set_ylabel(lab, fontsize=7)
        if k == "far": ax.set_yscale("log"); ax.axhline(0.1, color="k", lw=0.7, ls=":")
        else: ax.set_ylim(60 if k != "macro_f1" else 80, 100.5)
    axs[0].legend(fontsize=5.5, loc="lower left"); fig.suptitle(r"CICIDS2017 leakage audit ($\alpha$=0.001)", fontsize=8)
    fig.tight_layout(); savefig(fig, "N25_leakage_audit")

# ---------------------------------------------------------------- CV boxplots + CD diagram
if os.path.exists(os.path.join(RES, "stats.json")):
    st = load_json("stats.json")
    for t in [x for x in DS if x in st]:
        folds = load_json(f"cv_{t}.json")["folds"]; ks = sorted(folds, key=int); meths = st[t]["methods"]
        fig, axs = plt.subplots(1, 3, figsize=(7.0, 2.8))
        for ax, (k, lab) in zip(axs, [("mcc", "MCC"), ("tpr", "TPR"), ("far", "FAR (log)")]):
            data = [[folds[f][m][k] for f in ks] for m in meths]
            if k == "far": data = [[max(v, 1e-6) for v in dd] for dd in data]
            bp = ax.boxplot(data, vert=False, widths=0.6, patch_artist=True, medianprops=dict(color="k", lw=0.8),
                            flierprops=dict(ms=2), boxprops=dict(lw=0.6), whiskerprops=dict(lw=0.6), capprops=dict(lw=0.6))
            for p, m in zip(bp["boxes"], meths): p.set_facecolor(C["verm"] if "CREF" in m else ("#F3C6E2" if "Fisher" in m else "#D9D9D9"))
            ax.set_yticks(range(1, len(meths) + 1)); ax.set_yticklabels(meths if k == "mcc" else [], fontsize=6)
            if k == "far": ax.set_xscale("log"); ax.axvline(ALPHA[t], color="k", lw=0.7, ls=":")
            ax.set_xlabel(lab, fontsize=7); ax.tick_params(axis="x", labelsize=6)
        fig.suptitle(f"{DS[t]}: 10-fold CV (full leakage-free protocol per fold), $\\alpha$={ALPHA[t]:g}", fontsize=8)
        fig.tight_layout(); savefig(fig, f"N26_cv_boxplots_{t}")
        fig, axs = plt.subplots(2, 1, figsize=(7.0, 3.6))
        for ax, k in zip(axs, ["mcc", "far"]):
            mm = st[t]["metrics"][k]; ranks = mm["avg_rank"]; cd = mm["nemenyi_cd"]; n = len(ranks)
            items = sorted(ranks.items(), key=lambda x: x[1])
            ax.set_xlim(0.5, n + 0.5); ax.set_ylim(0, 1); ax.axis("off")
            ax.hlines(0.8, 1, n, color="k", lw=0.7)
            for r in range(1, n + 1):
                ax.vlines(r, 0.78, 0.82, color="k", lw=0.7); ax.text(r, 0.86, str(r), ha="center", fontsize=6.5)
            for i, (m, r) in enumerate(items):
                left = i < (n + 1) // 2; yy = 0.66 - (i if left else n - 1 - i) * 0.085
                ax.plot([r, r], [0.8, yy], color="k", lw=0.5)
                xe = 0.6 if left else n + 0.4
                ax.plot([r, xe], [yy, yy], color="k", lw=0.5)
                ax.text(xe + (-0.05 if left else 0.05), yy, f"{m} ({r:.2f})", ha="right" if left else "left", va="center",
                        fontsize=6, color=C["verm"] if "CREF" in m else "k")
            ax.plot([1, 1 + cd], [0.95, 0.95], color=C["blue"], lw=2); ax.text(1 + cd / 2, 0.97, f"CD = {cd:.2f}", ha="center", fontsize=6.5)
            # maximal cliques only (groups not significantly different)
            yb = 0.74; r_sorted = [r for _, r in items]; prev_b = -1
            for a_ in range(n):
                b_ = max(bb for bb in range(a_, n) if r_sorted[bb] - r_sorted[a_] <= cd)
                if b_ > a_ and b_ > prev_b:
                    ax.plot([r_sorted[a_] - 0.03, r_sorted[b_] + 0.03], [yb, yb], color="k", lw=1.6); yb -= 0.03
                prev_b = max(prev_b, b_)
            ax.set_title(f"{DS[t]}: Nemenyi critical difference, {k.upper()} (rank 1 = best"
                         + (", lower FAR is better)" if k == "far" else ")") +
                         f"; Friedman p={mm['friedman_p']:.1e}", fontsize=7.5)
        fig.tight_layout(); savefig(fig, f"N27_cd_diagram_{t}")

# ---------------------------------------------------------------- latency
if os.path.exists(os.path.join(RES, "timing_cic.json")):
    tm = load_json("timing_cic.json"); on = tm["online"]; names = list(on)
    fig, axs = plt.subplots(1, 2, figsize=(7.0, 2.4))
    w = 0.26
    for q, (k, col) in enumerate([("p50", C["green"]), ("p95", C["blue"]), ("p99", C["verm"])]):
        axs[0].barh(np.arange(len(names)) + (q - 1) * w, [on[n][k] for n in names], w, color=col, label=k.upper())
    axs[0].set_yticks(range(len(names))); axs[0].set_yticklabels(names, fontsize=6.3); axs[0].set_xlabel("per-flow latency (ms), 1 thread")
    axs[0].legend(fontsize=6); axs[0].set_title("(a) online (one flow at a time)", fontsize=7.5)
    b = tm["batch"]; bn = [("XGBoost", b["xgb_flows_per_s"]), ("4 members", b["members_flows_per_s"]),
                           ("CREF fusion only", b["fusion_only_flows_per_s"]), ("ACT regime layer only", b["act_regime_layer_flows_per_s"]),
                           ("CREF total", b["cref_total_flows_per_s"]), ("CREF + ACT total", b["cref_act_total_flows_per_s"])]
    axs[1].barh(range(len(bn)), [v for _, v in bn], color=[C["blue"], "0.5", C["green"], C["orange"], C["verm"], C["verm"]])
    for i, (_, v) in enumerate(bn): axs[1].text(v * 1.1, i, f"{v:,.0f}", va="center", fontsize=6)
    axs[1].set_xscale("log"); axs[1].set_yticks(range(len(bn))); axs[1].set_yticklabels([n for n, _ in bn], fontsize=6.3)
    axs[1].set_xlabel("batch throughput (flows/s, log)"); axs[1].set_title("(b) batch mode (2 threads)", fontsize=7.5)
    fig.tight_layout(); savefig(fig, "N28_latency_throughput")

# ---------------------------------------------------------------- component ablation (fixed alpha)
abl = [("XGBoost (no cost)", "A  XGBoost, no cost weighting"), ("XGBoost", "B  + cost-sensitive (W_R=30)"),
       ("Soft voting", "C  + 4-member ensemble (soft voting)"),
       ("CREF w/o p-calibration", "D  class-robust weights on raw scores"),
       ("CREF w/o e-values (2 sum lam u)", "E  conformal p-averaging (no e-values)"),
       ("Uniform e-mean", "F  e-values, uniform weights"), ("CREF (proposed)", "G  CREF (class-robust e-fusion)")]
fig, axs = plt.subplots(1, 4, figsize=(7.0, 2.7), sharey=True)
for j, t in enumerate(DS):
    r = load_json(f"core_{t}.json")["at_alpha"][str(ALPHA[t])]
    for i, (k, lab) in enumerate([("macro_f1", "Macro-F1 (%)"), ("far", "FAR (%)")]):
        ax = axs[2 * j + i]; v = [r[m][k] * 100 for m, _ in abl]
        ax.barh(range(len(abl)), v, color=[C["verm"] if "CREF (proposed)" == m else "0.6" for m, _ in abl], height=0.65)
        for y_, vv in enumerate(v): ax.text(vv * (1.05 if k == "far" else 1.0005), y_, f"{vv:.4f}" if k == "far" else f"{vv:.2f}",
                                            va="center", fontsize=5.4)
        if k == "far": ax.set_xscale("log"); ax.axvline(ALPHA[t] * 100, color="k", lw=0.7, ls=":")
        else: ax.set_xlim(min(v) - 2, 100.8)
        ax.set_xlabel(lab, fontsize=7); ax.set_title(f"{DS[t]}", fontsize=7.5); ax.tick_params(labelsize=6)
axs[0].set_yticks(range(len(abl))); axs[0].set_yticklabels([l for _, l in abl], fontsize=6.2); axs[0].invert_yaxis()
fig.tight_layout(); savefig(fig, "N29_component_ablation")
print("eval figs done")
