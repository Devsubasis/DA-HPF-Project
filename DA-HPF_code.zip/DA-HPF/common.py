"""DA-HPF v5 common code: data protocol, CREF, models, plotting style."""
import os, json, time
import numpy as np, pandas as pd

ROOT = os.path.dirname(os.path.abspath(__file__))
UP = os.environ.get("DAHPF_DATA", os.path.join(ROOT, "data"))
ART = os.path.join(ROOT, "art"); os.makedirs(ART, exist_ok=True)
FIG = os.path.join(ROOT, "figs"); os.makedirs(FIG, exist_ok=True)
RES = os.path.join(ROOT, "res"); os.makedirs(RES, exist_ok=True)
RS = 42
W_RARE = 30.0
MODEL_ORDER = ["rf", "xgb", "lgbm", "cat"]
MODEL_NAME = {"rf": "RF", "xgb": "XGBoost", "lgbm": "LightGBM", "cat": "CatBoost"}
RARE = {"cic": {"BOT"}, "unsw": {"WORMS", "SHELLCODE", "BACKDOOR", "ANALYSIS"}}

CIC_FILES = ["Friday-WorkingHours-Afternoon-DDos.pcap_ISCX.csv",
             "Friday-WorkingHours-Afternoon-PortScan.pcap_ISCX.csv",
             "Friday-WorkingHours-Morning.pcap_ISCX.csv"]
UNSW_FILES = ["UNSW_NB15_training-set.csv", "UNSW_NB15_testing-set.csv"]


def data_path(name):
    """Find a dataset file in UP, accepting common renamings
    ('.pcap_ISCX' vs '_pcap_ISCX', '-set.csv' vs '-set_in_.csv')."""
    cands = [name, name.replace(".pcap_ISCX", "_pcap_ISCX"), name.replace(".csv", "_in_.csv"),
             name.replace(".csv", "(in).csv")]
    for c in cands:
        p = os.path.join(UP, c)
        if os.path.exists(p):
            return p
    raise FileNotFoundError(f"{name} not found in {UP} (set DAHPF_DATA to the dataset folder)")


def save_json(obj, name):
    def conv(o):
        if isinstance(o, (np.floating,)): return float(o)
        if isinstance(o, (np.integer,)): return int(o)
        if isinstance(o, np.ndarray): return o.tolist()
        if isinstance(o, (np.bool_,)): return bool(o)
        raise TypeError(type(o))
    json.dump(obj, open(os.path.join(RES, name), "w"), indent=1, default=conv)


def load_json(name):
    return json.load(open(os.path.join(RES, name)))


# ------------------------------------------------------------------ raw data
def load_cic_raw():
    frames = []
    for i, f in enumerate(CIC_FILES):
        d = pd.read_csv(data_path(f), low_memory=False)
        d.columns = d.columns.str.strip()
        d["__file"] = i
        d["__row"] = np.arange(len(d))
        frames.append(d)
    df = pd.concat(frames, ignore_index=True, sort=False)
    n_raw = len(df)
    lab = df["Label"].astype(str).str.upper().str.strip()
    feats = [c for c in df.columns if c not in ("Label", "__file", "__row")]
    X = df[feats].apply(pd.to_numeric, errors="coerce").replace([np.inf, -np.inf], np.nan)
    ok = X.notna().all(axis=1).values
    X = X[ok].astype(np.float64)
    meta = dict(n_raw=n_raw, n_clean=int(ok.sum()))
    return (X.reset_index(drop=True), lab[ok].reset_index(drop=True).values,
            df["__file"].values[ok], df["__row"].values[ok], meta)


def load_unsw_raw():
    tr = pd.read_csv(data_path(UNSW_FILES[0]))
    te = pd.read_csv(data_path(UNSW_FILES[1]))
    for c in ["proto", "service", "state"]:
        cats = {v: i for i, v in enumerate(sorted(tr[c].astype(str).unique()))}
        tr[c] = tr[c].astype(str).map(cats)
        te[c] = te[c].astype(str).map(cats).fillna(-1)
    drop = ["id", "attack_cat", "label"]
    feats = [c for c in tr.columns if c not in drop]
    Xtr = tr[feats].astype(np.float64).replace([np.inf, -np.inf], 0).fillna(0)
    Xte = te[feats].astype(np.float64).replace([np.inf, -np.inf], 0).fillna(0)
    ltr = tr["attack_cat"].astype(str).str.upper().str.strip().values
    lte = te["attack_cat"].astype(str).str.upper().str.strip().values
    ltr = np.where(ltr == "NORMAL", "BENIGN", ltr)
    lte = np.where(lte == "NORMAL", "BENIGN", lte)
    return Xtr, ltr, Xte, lte


def logbot(X):
    """LogBot transform x' = log(1 + |x|)."""
    return np.log1p(np.abs(np.asarray(X, dtype=np.float64)))


def partition_val(lab_val, rng):
    """Validation -> TUNE (all attacks + 30% benign), CAL (55% benign),
    BAG0 (15% benign). Returns index arrays into the validation block."""
    ben = np.where(lab_val == "BENIGN")[0]
    atk = np.where(lab_val != "BENIGN")[0]
    ben = rng.permutation(ben)
    n = len(ben); a, b = int(0.30 * n), int(0.85 * n)
    tune = np.sort(np.concatenate([atk, ben[:a]]))
    return tune, np.sort(ben[a:b]), np.sort(ben[b:])


# ------------------------------------------------------------------ models
def make_models(fast=False):
    from sklearn.ensemble import RandomForestClassifier
    from xgboost import XGBClassifier
    from lightgbm import LGBMClassifier
    from catboost import CatBoostClassifier
    nb = 200 if fast else 300
    return {
        "rf": RandomForestClassifier(n_estimators=60 if fast else 120, max_samples=0.5,
                                     n_jobs=2, class_weight="balanced_subsample",
                                     min_samples_leaf=1, random_state=RS),
        "xgb": XGBClassifier(n_estimators=nb, max_depth=8, learning_rate=0.1,
                             subsample=0.9, colsample_bytree=0.9, tree_method="hist",
                             eval_metric="logloss", n_jobs=2, random_state=RS),
        "lgbm": LGBMClassifier(n_estimators=nb, num_leaves=64, learning_rate=0.1,
                               subsample=0.9, subsample_freq=1, colsample_bytree=0.9,
                               n_jobs=2, random_state=RS, verbose=-1),
        "cat": CatBoostClassifier(iterations=150 if fast else 300, depth=8,
                                  learning_rate=0.1, random_seed=RS, verbose=0,
                                  thread_count=2, allow_writing_files=False),
    }


def rare_weights(lab, ds):
    return np.where(np.isin(lab, list(RARE[ds])), W_RARE, 1.0)


def score_matrix(models, X, batch=100000):
    cols = []
    for k in MODEL_ORDER:
        m = models[k]
        cols.append(np.concatenate([m.predict_proba(X[s:s + batch])[:, 1]
                                    for s in range(0, len(X), batch)]))
    return np.stack(cols, 1)


# ------------------------------------------------------------------ CREF
def build_refs(S_benign):
    return [np.sort(S_benign[:, k]) for k in range(S_benign.shape[1])]


def conformal_u(refs, S):
    """u_k = (1 + #{b in B_k : b >= s_k}) / (n_b + 1)  (conservative ties)."""
    U = np.empty(S.shape)
    for k in range(S.shape[1]):
        r = refs[k]
        ge = len(r) - np.searchsorted(r, S[:, k], side="left")
        U[:, k] = (1.0 + ge) / (len(r) + 1.0)
    return U


def e_vals(U, kappa):
    return kappa * np.power(U, kappa - 1.0)


def e_max(kappa, n_b):
    return kappa * (n_b + 1.0) ** (1.0 - kappa)


def kappa_opt(n_b):
    return 1.0 / np.log(n_b + 1.0)


def nb_required(alpha, iters=50):
    """Smallest n_b with max_kappa E_max >= 1/alpha:  (n_b+1)/(e ln(n_b+1)) >= 1/alpha."""
    N = np.e / alpha * np.log(np.e / alpha)
    for _ in range(iters):
        N = np.e / alpha * np.log(N)
    return int(np.ceil(N - 1))


def project_simplex(v):
    u = np.sort(v)[::-1]; css = np.cumsum(u)
    rho = np.nonzero(u * np.arange(1, len(v) + 1) > (css - 1))[0][-1]
    return np.maximum(v - (css[rho] - 1.0) / (rho + 1.0), 0.0)


def class_robust_lambda(E_by_class, iters=1500, seed=RS):
    K = E_by_class[0].shape[1]
    rng = np.random.RandomState(seed)
    starts = [np.ones(K) / K] + [np.eye(K)[k] * 0.9 + 0.1 / K for k in range(K)] \
             + [project_simplex(rng.rand(K)) for _ in range(2)]
    best = (None, -np.inf)
    for lam in starts:
        lam = lam.copy()
        for t in range(1, iters + 1):
            vals = [np.mean(np.log(Ec @ lam)) for Ec in E_by_class]
            c = int(np.argmin(vals)); Ec = E_by_class[c]
            g = np.mean(Ec / (Ec @ lam)[:, None], axis=0)
            lam = project_simplex(lam + (0.5 / np.sqrt(t)) * g)
        obj = min(np.mean(np.log(Ec @ lam)) for Ec in E_by_class)
        if obj > best[1]:
            best = (lam, obj)
    return best


def select_kappa_lambda(S_tune, lab_tune, classes,
                        kappas=(0.05, 0.075, 0.1, 0.15, 0.2, 0.3, 0.5)):
    refs = build_refs(S_tune[lab_tune == "BENIGN"])
    U = conformal_u(refs, S_tune)
    masks = [lab_tune == c for c in classes]
    out = {"grid": []}; best = None
    for kap in kappas:
        E = e_vals(U, kap)
        lam, obj = class_robust_lambda([E[m] for m in masks])
        per = {c: float(np.mean(np.log(E[m] @ lam))) for c, m in zip(classes, masks)}
        uni = min(np.mean(np.log(E[m] @ (np.ones(4) / 4))) for m in masks)
        out["grid"].append(dict(kappa=kap, lam=lam.tolist(), obj=float(obj),
                                obj_uniform=float(uni), per_class=per))
        if best is None or obj > best[2]:
            best = (kap, lam, obj)
    out.update(kappa=best[0], lam=best[1].tolist(), obj=float(best[2]))
    return out


def cref_E(refs, S, kappa, lam):
    return e_vals(conformal_u(refs, S), kappa) @ np.asarray(lam)


# ------------------------------------------------------------------ plotting
def style():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({
        "font.family": "serif",
        "font.serif": ["Times New Roman", "Liberation Serif", "Nimbus Roman",
                       "DejaVu Serif"],
        "mathtext.fontset": "stix", "font.size": 9, "axes.titlesize": 9.5,
        "axes.labelsize": 9, "legend.fontsize": 7.5, "xtick.labelsize": 8,
        "ytick.labelsize": 8, "axes.linewidth": 0.6, "lines.linewidth": 1.4,
        "xtick.direction": "in", "ytick.direction": "in",
        "xtick.major.width": 0.6, "ytick.major.width": 0.6,
        "figure.facecolor": "white", "axes.facecolor": "white",
        "savefig.facecolor": "white", "legend.frameon": True,
        "legend.edgecolor": "0.75", "legend.framealpha": 0.95,
        "axes.grid": False, "grid.color": "0.88", "grid.linewidth": 0.5,
    })
    return plt


# Okabe-Ito (validated CVD-safe; pair with markers/linestyles)
C = {"blue": "#0072B2", "verm": "#D55E00", "green": "#009E73", "pink": "#CC79A7",
     "orange": "#E69F00", "sky": "#56B4E9", "black": "#000000", "gray": "#7F7F7F"}
MCOL = {"rf": C["green"], "xgb": C["blue"], "lgbm": C["orange"], "cat": C["pink"],
        "cref": C["verm"]}
CLS_COL = {"BENIGN": "#9AA0A6", "DDOS": C["blue"], "PORTSCAN": C["orange"],
           "BOT": C["verm"]}


def savefig(fig, name):
    for ext in ("pdf", "png"):
        fig.savefig(os.path.join(FIG, f"{name}.{ext}"), dpi=600, bbox_inches="tight")
    import matplotlib.pyplot as plt
    plt.close(fig)
