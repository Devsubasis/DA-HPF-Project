"""10-fold stratified CV with the full leakage-free protocol inside every fold.
usage: python cv.py DS [FOLDS e.g. 0-9]   (DS = cic | unsw; unsw uses the official training partition)"""
import sys, numpy as np
from scipy.stats import chi2
from sklearn.model_selection import StratifiedKFold, train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (f1_score, matthews_corrcoef, average_precision_score,
                             roc_auc_score, balanced_accuracy_score)
from common import *
from prep import select_features

ds = sys.argv[1]
lo, hi = (int(x) for x in (sys.argv[2] if len(sys.argv) > 2 else "0-9").split("-"))
out_name = f"cv_{ds}.json"
res = load_json(out_name) if os.path.exists(os.path.join(RES, out_name)) else {"folds": {}}
if ds == "cic":
    Xdf, lab, *_ = load_cic_raw(); fit_frac = 0.75; alpha = 1e-3
else:
    Xdf, lab, _, _ = load_unsw_raw(); fit_frac = 0.70; alpha = 1e-2
names = list(Xdf.columns); X = Xdf.values
classes_all = [c for c in np.unique(lab) if c != "BENIGN"]


def m(yhat, y, lab_, s=None):
    o = dict(macro_f1=f1_score(y, yhat, average="macro"), mcc=matthews_corrcoef(y, yhat),
             bal_acc=balanced_accuracy_score(y, yhat),
             far=float(yhat[y == 0].mean()), tpr=float(yhat[y == 1].mean()),
             min_class_recall=float(min(yhat[lab_ == c].mean() for c in classes_all if (lab_ == c).any())))
    if s is not None: o["pr_auc"] = average_precision_score(y, s); o["roc_auc"] = roc_auc_score(y, s)
    return o


skf = StratifiedKFold(n_splits=10, shuffle=True, random_state=RS)
for f, (tr, te) in enumerate(skf.split(X, lab)):
    if f < lo or f > hi or str(f) in res["folds"]: continue
    t0 = time.time()
    ltr = lab[tr]
    fi, vi = train_test_split(np.arange(len(tr)), test_size=1 - fit_frac, stratify=ltr, random_state=RS)
    t_i, c_i, _ = partition_val(ltr[vi], np.random.RandomState(RS + f))
    feats, _ = select_features(X[tr][fi], ltr[fi], names)
    cols = [names.index(c) for c in feats]
    L = logbot(X[:, cols]); mu, sd = L[tr][fi].mean(0), L[tr][fi].std(0); sd[sd == 0] = 1
    Z = ((L - mu) / sd).astype(np.float32)
    Zfit, Ztune, Zcal, Zte = Z[tr][fi], Z[tr][vi[t_i]], Z[tr][vi[c_i]], Z[te]
    lt, lte = ltr[vi[t_i]], lab[te]; y = (ltr[fi] != "BENIGN").astype(int); yte = (lte != "BENIGN").astype(int)
    models = make_models(fast=False)
    for k, mdl in models.items(): mdl.fit(Zfit, y, sample_weight=rare_weights(ltr[fi], ds))
    St, Sc, Se = score_matrix(models, Ztune), score_matrix(models, Zcal), score_matrix(models, Zte)
    sel = select_kappa_lambda(St, lt, [c for c in np.unique(lt) if c != "BENIGN"])
    kap, lam = sel["kappa"], np.array(sel["lam"])
    U = conformal_u(build_refs(Sc), Se); E = e_vals(U, kap) @ lam; Eu = e_vals(U, kap).mean(1)
    def lg(S): return np.log(np.clip(S, 1e-7, 1)) - np.log(np.clip(1 - S, 1e-7, 1))
    stk = LogisticRegression(max_iter=2000).fit(lg(St), (lt != "BENIGN").astype(int))
    sc = {"RF": (Se[:, 0], Sc[:, 0]), "XGBoost": (Se[:, 1], Sc[:, 1]), "LightGBM": (Se[:, 2], Sc[:, 2]),
          "CatBoost": (Se[:, 3], Sc[:, 3]), "Soft voting": (Se.mean(1), Sc.mean(1)),
          "Stacking (LR)": (stk.predict_proba(lg(Se))[:, 1], stk.predict_proba(lg(Sc))[:, 1])}
    fold = {}
    for nm, (s_te, s_cal) in sc.items():
        thr = np.quantile(s_cal, 1 - alpha, method="higher")
        fold[nm] = m((s_te > thr).astype(int), yte, lte, s_te)
    fold["Fisher (indep.)"] = m((chi2.sf(-2 * np.log(U).sum(1), 8) <= alpha).astype(int), yte, lte)
    fold["Bonferroni"] = m((4 * U.min(1) <= alpha).astype(int), yte, lte, -U.min(1))
    fold["Uniform e-mean"] = m((Eu >= 1 / alpha).astype(int), yte, lte, Eu)
    fold["CREF (proposed)"] = m((E >= 1 / alpha).astype(int), yte, lte, E)
    fold["_meta"] = dict(kappa=kap, lam=lam.tolist(), n_b=len(Sc), E_max=e_max(kap, len(Sc)),
                         secs=time.time() - t0)
    res["folds"][str(f)] = fold; save_json(res, out_name)
    print(f"[cv {ds} fold {f}] {time.time()-t0:.0f}s kappa={kap} lam={np.round(lam,2).tolist()} "
          f"CREF mcc={fold['CREF (proposed)']['mcc']:.4f} far={fold['CREF (proposed)']['far']:.5f} | "
          f"XGB mcc={fold['XGBoost']['mcc']:.4f} far={fold['XGBoost']['far']:.5f}", flush=True)
