"""Oracle matched-FAR analysis (test-tuned thresholds; analysis only, never used for deployment).
usage: python matched_far.py"""
import numpy as np
from common import *
out = {}
for t in ["cic", "unsw"]:
    ev = np.load(os.path.join(ART, f"evid_{t}.npz"), allow_pickle=True); core = load_json(f"core_{t}.json")
    y, lab = ev["yte"], ev["lte"]; a = "0.001" if t == "cic" else "0.01"
    far_c = core["at_alpha"][a]["CREF (proposed)"]["far"]
    s = np.load(os.path.join(ART, f"scores_{t}.npz"))["S_te"]
    cand = {"XGBoost": s[:, 1], "LightGBM": s[:, 2], "RF": s[:, 0], "CatBoost": s[:, 3], "Soft voting": ev["soft"],
            "Stacking (LR)": ev["stack"], "Uniform e-mean": ev["E_uni"], "CREF (proposed)": ev["E"]}
    res = {}
    for nm, sc in cand.items():
        ben = np.sort(sc[y == 0]); nb = len(ben); k = int(np.floor(far_c * nb))
        thr = ben[nb - k - 1] if k < nb else -np.inf
        yh = sc > thr
        res[nm] = dict(far=float(yh[y == 0].mean()), tpr=float(yh[y == 1].mean()),
                       per_class={c: float(yh[lab == c].mean()) for c in np.unique(lab) if c != "BENIGN"})
    out[t] = dict(target_far=far_c, cref_at_alpha_tpr=core["at_alpha"][a]["CREF (proposed)"]["rec"], matched=res)
    print(t, "matched FAR", far_c, {k: round(v["tpr"] * 100, 3) for k, v in res.items()})
save_json(out, "matched_far.json")
