"""AdaBoost baseline under the same protocol.  usage: python extra_models.py cic unsw"""
import sys, numpy as np
from sklearn.ensemble import AdaBoostClassifier
from common import *
for variant in sys.argv[1:]:
    d = np.load(os.path.join(ART, f"{variant}.npz"), allow_pickle=True)
    ds = "unsw" if variant.startswith("unsw") else "cic"
    m = AdaBoostClassifier(n_estimators=200, learning_rate=0.5, random_state=RS)
    t0 = time.time(); m.fit(d["Xfit"], (d["lfit"] != "BENIGN").astype(int), sample_weight=rare_weights(d["lfit"], ds))
    np.savez_compressed(os.path.join(ART, f"ada_{variant}.npz"), te=m.predict_proba(d["Xte"])[:, 1],
                        cal=m.predict_proba(d["Xcal"])[:, 1])
    print(variant, "adaboost", round(time.time() - t0), "s", flush=True)
