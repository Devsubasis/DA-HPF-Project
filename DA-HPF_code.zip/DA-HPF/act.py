"""ACT v5: Adaptive Conformal Triage with provable guarantees.

Per-flow layer (frozen calibration):  DROP_t = 1{A_t >= 1/alpha_t}, MONITOR_t = 1{1/(rho alpha_t) <= A_t < 1/alpha_t}
  alpha_t predictable (depends only on mode_{t-1}, L_{t-1}); token bucket
  L_t = min(L_max, L_{t-1} + abar - alpha_t),  alpha_t <= L_{t-1} + abar
  => sum_{s<=t} alpha_s <= abar*t + L_0  =>  E[#benign false drops up to T] <= abar*T + L_0.
Regime layer (online conformal e-detector):
  p_t = [#{a in B_{t-1}: a > A_t} + tau_t (#{a in B_{t-1}: a = A_t} + 1)] / (|B_{t-1}| + 1)
  e_t = ks * p_t^(ks-1);  C_t = e_t * max(C_{t-1}, 1);  ALERT if C_t >= 1/alpha_reg
  bag grows in CALM, frozen in ALERT; exit when sum_{s=t-D+1}^{t} 1{e_s >= 1} <= q*D
  (benign rate of {e_s >= 1} is exactly ks^(1/(1-ks)) = 0.0774 for ks = 0.1), then reset bag to B_0.
"""
import numpy as np
from sortedcontainers import SortedList

CALM, ALERT = 0, 1


def online_p(bag, a, tau):
    lo, hi = bag.bisect_left(a), bag.bisect_right(a)
    n = len(bag)
    return ((n - hi) + tau * (hi - lo + 1)) / (n + 1)


def act_run(A, A_bag0, P, rng):
    """A: CREF evidence of the stream (frozen refs). A_bag0: evidence of the benign bag B_0.
    P: dict(ks, alpha_reg, D, a_calm, a_alert, abar, L_max, rho). Returns dict of arrays."""
    T = len(A)
    bag0 = SortedList(A_bag0.tolist()); bag = SortedList(bag0)
    ks, thr_reg, D = P["ks"], 1.0 / P["alpha_reg"], P["D"]
    L = P["L_max"]; mode = CALM; C = 0.0; win = []; since = 0
    qD = int(np.floor(P.get("q", 0.15) * D))
    out = {k: np.empty(T) for k in ["alpha", "C", "p", "L"]}
    out["mode"] = np.empty(T, np.int8); out["dec"] = np.empty(T, np.int8); out["e"] = np.empty(T)
    taus = rng.random_sample(T)
    for t in range(T):
        # ---- predictable level (uses only state up to t-1)
        tgt = P["a_alert"] if mode == ALERT else P["a_calm"]
        alpha = min(tgt, L + P["abar"])
        L = min(P["L_max"], L + P["abar"] - alpha)
        a = A[t]
        out["dec"][t] = 2 if a >= 1.0 / alpha else (1 if a >= 1.0 / min(1.0, P["rho"] * alpha) else 0)
        out["alpha"][t] = alpha; out["L"][t] = L; out["mode"][t] = mode
        # ---- regime e-detector
        p = online_p(bag, a, taus[t]); e = ks * p ** (ks - 1.0)
        C = e * max(C, 1.0); out["C"][t] = C; out["p"][t] = p; out["e"][t] = e
        if mode == CALM:
            bag.add(a)
            if C >= thr_reg:
                mode = ALERT; win = []; since = 0
        else:
            win.append(e >= 1.0); since += 1
            if len(win) > D: win.pop(0)
            if since >= D and sum(win) <= qD:
                mode = CALM; C = 0.0; bag = SortedList(bag0)
    return out


def heuristic_run(r, W=300, T0=0.5, kappa=0.5, tmin=0.15, tmax=0.98, t_mon=None):
    """Previous-version ACT: threshold T_t = clip(T0 (1 - kappa*theta_{t-1}), tmin, tmax),
    theta = P95 of the last W risk scores. No budget, no guarantee."""
    T = len(r); thr = np.empty(T); dec = np.empty(T, np.int8)
    buf = []; theta = 0.0
    for t in range(T):
        Tt = float(np.clip(T0 * (1 - kappa * theta), tmin, tmax)); thr[t] = Tt
        dec[t] = 2 if r[t] >= Tt else (1 if r[t] >= 0.5 * Tt else 0)
        buf.append(r[t])
        if len(buf) > W: buf.pop(0)
        if t % 20 == 19:
            theta = float(np.percentile(buf, 95))
    return dict(thr=thr, dec=dec)
