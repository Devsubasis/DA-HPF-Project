"""Statistics on 10-fold CV: mean +- SD, 95% t-CI, Friedman + Kendall W, exact Wilcoxon
(CREF vs each method) with Holm correction, rank-biserial r and Cohen's d_z, Nemenyi CD."""
import numpy as np
from scipy.stats import friedmanchisquare, wilcoxon, t as tdist, studentized_range
from common import *

METHODS = ["RF", "XGBoost", "LightGBM", "CatBoost", "Soft voting", "Stacking (LR)", "Bonferroni",
           "Uniform e-mean", "CREF (proposed)", "Fisher (indep.)"]
METRICS = {"mcc": +1, "macro_f1": +1, "tpr": +1, "far": -1, "min_class_recall": +1, "bal_acc": +1}


def holm(p):
    p = np.asarray(p); o = np.argsort(p); m = len(p); adj = np.empty(m); run = 0
    for i, j in enumerate(o):
        run = max(run, min(1, (m - i) * p[j])); adj[j] = run
    return adj


out = {}
for ds in ["cic", "unsw"]:
    f = os.path.join(RES, f"cv_{ds}.json")
    if not os.path.exists(f): continue
    folds = load_json(f"cv_{ds}.json")["folds"]; ks = sorted(folds, key=int); n = len(ks)
    meths = [m for m in METHODS if m in folds[ks[0]]]
    o = dict(n_folds=n, methods=meths, metrics={})
    for met, sgn in METRICS.items():
        M = np.array([[folds[k][m][met] for m in meths] for k in ks])          # n x methods
        mean, sd = M.mean(0), M.std(0, ddof=1); h = tdist.ppf(0.975, n - 1) * sd / np.sqrt(n)
        desc = {m: dict(mean=float(mean[i]), sd=float(sd[i]), ci=[float(mean[i] - h[i]), float(mean[i] + h[i])])
                for i, m in enumerate(meths)}
        # ranks: 1 = best
        R = np.array([np.argsort(np.argsort(-sgn * row, kind="stable"), kind="stable") + 1 for row in M], float)
        # average ties
        from scipy.stats import rankdata
        R = np.array([rankdata(-sgn * row) for row in M])
        avg = R.mean(0)
        try:
            chi, pf = friedmanchisquare(*[M[:, i] for i in range(len(meths))])
        except Exception:
            chi, pf = np.nan, np.nan
        W = chi / (n * (len(meths) - 1)) if np.isfinite(chi) else np.nan
        q = studentized_range.ppf(0.95, len(meths), np.inf) / np.sqrt(2)
        cd = q * np.sqrt(len(meths) * (len(meths) + 1) / (6 * n))
        ci_ = meths.index("CREF (proposed)"); pw, rows = [], []
        for i, m in enumerate(meths):
            if i == ci_: continue
            dlt = M[:, ci_] - M[:, i]
            if np.allclose(dlt, 0):
                p, stat = 1.0, 0.0
            else:
                r_ = wilcoxon(M[:, ci_], M[:, i], method="exact" if not np.any(dlt == 0) else "auto")
                p, stat = float(r_.pvalue), float(r_.statistic)
            nz = dlt[dlt != 0]; rk = rankdata(np.abs(nz))
            rb = float((rk[nz > 0].sum() - rk[nz < 0].sum()) / rk.sum()) if len(nz) else 0.0
            dz = float(dlt.mean() / dlt.std(ddof=1)) if dlt.std(ddof=1) > 0 else 0.0
            rows.append(dict(vs=m, mean_diff=float(dlt.mean()), W=stat, p=p, rank_biserial=rb, cohen_dz=dz,
                             better_direction="higher" if sgn > 0 else "lower")); pw.append(p)
        for r_, a in zip(rows, holm(pw)): r_["p_holm"] = float(a)
        o["metrics"][met] = dict(desc=desc, avg_rank={m: float(avg[i]) for i, m in enumerate(meths)},
                                 friedman_chi2=float(chi), friedman_p=float(pf), kendall_W=float(W), nemenyi_cd=float(cd),
                                 pairwise_cref=rows)
    out[ds] = o
    m = o["metrics"]
    print(f"\n== {ds} (n={n}) ==")
    for met in ["mcc", "far", "tpr", "macro_f1"]:
        x = m[met]
        print(f"{met}: Friedman chi2={x['friedman_chi2']:.2f} p={x['friedman_p']:.2e} W={x['kendall_W']:.3f} CD={x['nemenyi_cd']:.2f}")
        for r_ in x["pairwise_cref"]:
            print(f"   CREF vs {r_['vs']:16s} diff={r_['mean_diff']:+.6f} p={r_['p']:.4f} holm={r_['p_holm']:.4f} "
                  f"rb={r_['rank_biserial']:+.2f} dz={r_['cohen_dz']:+.2f}")
save_json(out, "stats.json")
