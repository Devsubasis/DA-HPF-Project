"""ACT figures: dynamics trace (replaces previous threshold-evolution figure), regime-detector
validity (run lengths vs 1/alpha_reg, Ville crossing probabilities), six-regime comparison,
delay/recovery, cumulative false drops vs budget."""
import joblib, numpy as np
from common import *
plt = style()

DS = {"cic": "CICIDS2017", "unsw": "UNSW-NB15"}
act = {t: load_json(f"act_{t}.json") for t in DS}
tr = {t: joblib.load(os.path.join(ART, f"act_traces_{t}.joblib")) for t in DS}

# ---------------------------------------------------------------- dynamics trace (CIC repeated waves)
for t in DS:
    T = tr[t]["R3 repeated waves"]; n = len(T["A"]); x = np.arange(n); lab = T["lab"]; ben = lab == "BENIGN"
    fig, axs = plt.subplots(4, 1, figsize=(7.0, 5.6), sharex=True, gridspec_kw=dict(height_ratios=[1.5, 1, 0.7, 1]))
    def shade(ax):
        for s0, s1 in T["waves"]: ax.axvspan(s0, s1, color="#FCE5DA", zorder=0, lw=0)
        on = np.flatnonzero(np.diff(np.r_[0, T["mode"], 0]) == 1); off = np.flatnonzero(np.diff(np.r_[0, T["mode"], 0]) == -1)
        for a, b in zip(on, off): ax.axvspan(a, b, ymin=0.0, ymax=0.06, color=C["verm"], lw=0)
    ax = axs[0]; shade(ax)
    le = np.log10(T["A"]); rng = np.random.RandomState(0); jit = rng.normal(0, 0.02, n)
    ax.scatter(x[ben], le[ben] + jit[ben], s=1.2, color="0.6", linewidths=0, rasterized=True, label="benign flow")
    ax.scatter(x[~ben], le[~ben] + jit[~ben], s=1.2, color=C["blue"], linewidths=0, rasterized=True, label="attack flow")
    ax.step(x, np.log10(1 / T["alpha"]), where="post", color=C["verm"], lw=1.1, label=r"DROP threshold $\log_{10}(1/\alpha_t)$")
    ax.step(x, np.log10(1 / np.minimum(1, act[t]["params"]["rho"] * T["alpha"])), where="post", color="k", lw=0.8, ls="--",
            label=r"MONITOR threshold $\log_{10}(1/\rho\alpha_t)$")
    ax.set_ylabel(r"$\log_{10}E_t$"); ax.legend(fontsize=6, loc="lower right", ncol=2, markerscale=4)
    ax.set_title(f"{DS[t]}: ACT on a stream with three attack waves (shaded); red ticks = ALERT mode", fontsize=8)
    ax = axs[1]; shade(ax)
    ax.plot(x, np.clip(np.log10(np.maximum(T["C"], 1e-3)), -3, 12), color="k", lw=0.7)
    ax.set_ylim(-3.5, 12.8); ax.text(0.995, 0.93, "display clipped at $10^{12}$", transform=ax.transAxes, ha="right", fontsize=6)
    ax.axhline(np.log10(1 / act[t]["params"]["alpha_reg"]), color=C["verm"], lw=0.9, ls="--",
               label=r"regime threshold $1/\alpha_{reg}$")
    ax.set_ylabel(r"$\log_{10}C_t$"); ax.legend(fontsize=6, loc="center right")
    ax = axs[2]; shade(ax); ax.plot(x, T["L"], color=C["green"], lw=1.0); ax.set_ylabel(r"bucket $L_t$")
    ax = axs[3]; shade(ax)
    hb = (T["hdec"] == 2) & ben; ab = (T["dec"] == 2) & ben
    ax.plot(x, np.cumsum(hb), color=C["orange"], lw=1.1, label="benign drops: heuristic adaptive threshold")
    ax.plot(x, np.cumsum(ab), color=C["verm"], lw=1.3, label="benign drops: ACT")
    ax.plot(x, act[t]["params"]["abar"] * (x + 1) + act[t]["params"]["L_max"], color="k", lw=0.8, ls=":",
            label=r"ACT budget $\bar\alpha t+L_0$ (bound on expectation)")
    ax.set_yscale("symlog", linthresh=1); ax.set_ylabel("cumulative\nbenign drops"); ax.set_xlabel("flow index $t$")
    ax.legend(fontsize=6, loc="upper left")
    fig.tight_layout(); savefig(fig, f"P08_ACT_dynamics_{t}")

# ---------------------------------------------------------------- regime-detector validity
fig, axs = plt.subplots(1, 3, figsize=(7.0, 2.5))
for j, t in enumerate(DS):
    v = act[t]["regime_validity"]
    for areg, col, ls in [("0.01", C["blue"], "-"), ("0.001", C["verm"], "--")]:
        rl = np.sort(np.array(v[areg]["rl"])); cap = v[areg]["cap"]
        ax = axs[j]; ax.step(rl, np.arange(1, len(rl) + 1) / len(rl), color=col, ls=ls, lw=1.1,
                             label=f"$\\alpha_{{reg}}$={areg}: mean RL$\\geq${np.mean(rl):,.0f}")
        ax.axvline(1 / float(areg), color=col, lw=0.7, ls=":")
    ax.set_xscale("log"); ax.set_xlabel("run length to first false alarm (flows)")
    ax.set_ylabel("ECDF"); ax.legend(fontsize=5.8, loc="upper left")
    ax.set_title(f"({'ab'[j]}) {DS[t]}" + (" (exchangeable)" if t == "cic" else " (official split: shifted)"), fontsize=7.5)
ax = axs[2]; al = [0.1, 0.05, 0.01]; w = 0.35
for j, t in enumerate(DS):
    pv = [act[t]["regime_validity"]["0.01"]["ville"][str(a)] for a in al]
    ax.bar(np.arange(3) + (j - 0.5) * w, pv, w, color=[C["blue"], C["orange"]][j], label=DS[t])
ax.scatter(np.arange(3), al, marker="_", s=300, color="k", label=r"Ville bound $\alpha$", zorder=3)
ax.set_xticks(range(3)); ax.set_xticklabels([str(a) for a in al]); ax.set_xlabel(r"$\alpha$")
ax.set_ylabel(r"$P(\sup_t K_t\geq 1/\alpha)$"); ax.set_title("(c) time-uniform (Ville) check", fontsize=7.5)
ax.legend(fontsize=6)
fig.tight_layout(); savefig(fig, "N19_ACT_regime_validity_ARL_Ville")

# ---------------------------------------------------------------- six-regime comparison
meths = [("ACT (proposed)", C["verm"]), ("CREF fixed-alpha", C["blue"]), ("Heuristic adaptive (prev. ACT)", C["orange"])]
fig, axs = plt.subplots(2, 2, figsize=(7.0, 4.8))
for j, t in enumerate(DS):
    R = act[t]["regimes"]; regs = list(R); w = 0.26
    for i, (k, lab) in enumerate([("benign_drop", "benign false drops per stream"), ("drop_rate_attack", "attack drop rate (%)")]):
        ax = axs[i, j]
        for q, (m, col) in enumerate(meths):
            mu = np.array([R[r][m][k]["mean"] for r in regs]) * (100 if k == "drop_rate_attack" else 1)
            sd = np.array([R[r][m][k]["sd"] for r in regs]) * (100 if k == "drop_rate_attack" else 1)
            if k == "benign_drop": mu = np.maximum(mu, 0.05)
            ax.bar(np.arange(len(regs)) + (q - 1) * w, mu, w, yerr=sd, color=col, label=m, error_kw=dict(lw=0.6, capsize=1.5))
        if k == "benign_drop": ax.set_yscale("log")
        ax.set_xticks(range(len(regs))); ax.set_xticklabels([r.split(" ")[0] for r in regs], fontsize=7)
        ax.set_ylabel(lab, fontsize=7); ax.set_title(f"({'abcd'[2*i+j]}) {DS[t]}", fontsize=7.5)
        if i == 0 and j == 0: ax.legend(fontsize=6, loc="upper left")
names = "; ".join(r for r in act["cic"]["regimes"])
fig.text(0.5, -0.01, names, ha="center", fontsize=6)
fig.tight_layout(); savefig(fig, "N20_ACT_six_regimes")

# ---------------------------------------------------------------- delay / recovery / switches
fig, axs = plt.subplots(1, 3, figsize=(7.0, 2.3))
for k, ax, lab in [("detection_delay", axs[0], "regime detection delay (flows)"),
                   ("recovery_time", axs[1], "recovery time (flows)"), ("mode_switches", axs[2], "mode switches per stream")]:
    xs, labs = [], []
    for t, col in [("cic", C["blue"]), ("unsw", C["orange"])]:
        for r, v in act[t]["regimes"].items():
            a = v["ACT (proposed)"].get(k)
            if a is None or a.get("mean") is None: continue
            xs.append((t, r, a["mean"], a["sd"] or 0, col))
    y = np.arange(len(xs))
    ax.barh(y, [x[2] for x in xs], xerr=[x[3] for x in xs], color=[x[4] for x in xs], height=0.6, error_kw=dict(lw=0.6))
    ax.set_yticks(y); ax.set_yticklabels([f"{'CIC' if x[0]=='cic' else 'UNSW'} {x[1].split(' ')[0]}" for x in xs], fontsize=6)
    ax.set_xlabel(lab, fontsize=7)
fig.tight_layout(); savefig(fig, "N21_ACT_delay_recovery_switches")
print("ACT figs done")
