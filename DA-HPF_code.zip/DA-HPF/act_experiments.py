"""ACT validation: (1) regime-detector ARL & Ville checks on benign-only streams,
(2) per-flow false-drop budget, (3) six traffic regimes vs fixed-alpha CREF and the
heuristic adaptive threshold. usage: python act_experiments.py TAG VARIANT"""
import sys, joblib, numpy as np
from common import *
from act import act_run, heuristic_run, online_p
from sortedcontainers import SortedList

tag, variant = sys.argv[1], sys.argv[2]
ds = "unsw" if variant.startswith("unsw") else "cic"
d = np.load(os.path.join(ART, f"{variant}.npz"), allow_pickle=True)
s = np.load(os.path.join(ART, f"scores_{tag}.npz"), allow_pickle=True)
core = load_json(f"core_{tag}.json")
kap, lam = core["kappa"], np.array(core["lam"])
refs = build_refs(s["S_cal"]); n_b = len(s["S_cal"])
A_te = cref_E(refs, s["S_te"], kap, lam); A_b0 = cref_E(refs, s["S_bag0"], kap, lam)
soft_te = s["S_te"].mean(1)
lte = d["lte"]; ben_i = np.where(lte == "BENIGN")[0]
Emax = e_max(kap, n_b); a_min = 1 / Emax
P = dict(ks=0.1, alpha_reg=1e-6, D=200, q=0.15, abar=1e-3, L_max=10.0, rho=10.0,
         a_calm=None, a_alert=1e-2)
if ds == "unsw":
    P.update(abar=5e-3, a_alert=2e-2)
P["a_calm"] = max(0.9 * P["abar"], 1.01 * a_min)
print(f"[{tag}] n_b={n_b} E_max={Emax:.1f} a_min={a_min:.2e} params={P}", flush=True)
res = dict(params=P, E_max=Emax, alpha_min=a_min, n_bag0=len(A_b0))

# ---------------------------------------------------------------- (1) regime validity
def run_length(Astream, alpha_reg, ks, rng, cap):
    bag = SortedList(A_b0.tolist()); C = 0.0; logK = 0.0; supK = 0.0
    tau = rng.random_sample(len(Astream))
    for t in range(min(cap, len(Astream))):
        p = online_p(bag, Astream[t], tau[t]); e = ks * p ** (ks - 1)
        C = e * max(C, 1.0); logK += np.log(e); supK = max(supK, logK)
        bag.add(Astream[t])
        if C >= 1 / alpha_reg:
            return t + 1, supK, True
    return cap, supK, False

rng = np.random.RandomState(7)
val = {}
for areg, reps, cap in [(1e-2, 300, 5000), (1e-3, 120, 20000)]:
    rl, cens, sups = [], 0, []
    for r in range(reps):
        st = A_te[rng.permutation(ben_i)[:cap]]
        L_, supK, hit = run_length(st, areg, P["ks"], rng, cap)
        rl.append(L_); cens += (not hit); sups.append(supK)
    rl = np.array(rl); sups = np.array(sups)
    val[str(areg)] = dict(bound=1 / areg, reps=reps, cap=cap, censored=int(cens),
                          mean_rl_lower=float(rl.mean()), median_rl=float(np.median(rl)),
                          rl=rl.tolist(),
                          ville={str(a): float((sups >= np.log(1 / a)).mean()) for a in [0.1, 0.05, 0.01]})
    print(f"  ARL check alpha_reg={areg}: mean RL >= {rl.mean():.0f} (bound {1/areg:.0f}), "
          f"censored {cens}/{reps}; Ville P(sup K>=1/a): "
          + ", ".join(f"a={a}:{(sups >= np.log(1/a)).mean():.3f}" for a in [0.1, 0.05, 0.01]), flush=True)
res["regime_validity"] = val

# ---------------------------------------------------------------- (3) regimes
cls_atk = [c for c in np.unique(lte) if c != "BENIGN"]
atk_i = np.where(lte != "BENIGN")[0]
rare = sorted(RARE[ds] & set(cls_atk))
rare_i = np.where(np.isin(lte, rare))[0]

shift_scores = None
if ds == "cic":
    models = joblib.load(os.path.join(ART, f"models_{tag}.joblib"))
    Xb = d["Xte"][ben_i]; Xa = d["Xte"][atk_i]
    rs = np.random.RandomState(3)
    shift = 0.20 * rs.choice([-1, 1], Xb.shape[1])          # covariate shift in z-space
    Sb_sh = score_matrix(models, (Xb + shift).astype(np.float32))
    Sa_sh = score_matrix(models, (Xa + shift).astype(np.float32))
    shift_scores = dict(Ab=cref_E(refs, Sb_sh, kap, lam), Aa=cref_E(refs, Sa_sh, kap, lam),
                        rb=Sb_sh.mean(1), ra=Sa_sh.mean(1))


def segment(kind, n, rng, frac=0.8, pool=None, shifted=False):
    if kind == "benign":
        ii = rng.choice(len(ben_i), n, replace=False)
        if shifted: return shift_scores["Ab"][ii], shift_scores["rb"][ii], np.array(["BENIGN"] * n)
        g = ben_i[ii]; return A_te[g], soft_te[g], lte[g]
    na = int(round(frac * n)); nb = n - na
    pool = atk_i if pool is None else pool
    ja = rng.choice(len(pool), na, replace=len(pool) < na); jb = rng.choice(len(ben_i), nb, replace=False)
    if shifted:
        pa = np.searchsorted(atk_i, pool[ja])
        A = np.concatenate([shift_scores["Aa"][pa], shift_scores["Ab"][jb]])
        r = np.concatenate([shift_scores["ra"][pa], shift_scores["rb"][jb]])
        l = np.concatenate([lte[pool[ja]], np.array(["BENIGN"] * nb)])
    else:
        g = np.concatenate([pool[ja], ben_i[jb]]); A, r, l = A_te[g], soft_te[g], lte[g]
    o = rng.permutation(n); return A[o], r[o], l[o]


REG = {
    "R1 stable benign": [("benign", 20000)],
    "R2 sudden wave + recovery": [("benign", 6000), ("wave", 3000), ("benign", 6000)],
    "R3 repeated waves": [("benign", 4000), ("wave", 1000), ("benign", 3000), ("wave", 2000),
                          ("benign", 3000), ("wave", 500), ("benign", 4000)],
    "R4 mixed 10% attacks": [("mix10", 15000)],
    "R5 imbalanced 0.5% rare-class": [("rare05", 20000)],
}
if ds == "cic":
    REG["R6 distribution shift"] = [("benign", 8000), ("benign_sh", 8000), ("wave_sh", 3000), ("benign_sh", 4000)]


def build_stream(spec, rng):
    A, r, l, waves, bounds = [], [], [], [], []; t = 0
    for kind, n in spec:
        if kind == "benign": a_, r_, l_ = segment("benign", n, rng)
        elif kind == "benign_sh": a_, r_, l_ = segment("benign", n, rng, shifted=True)
        elif kind == "wave": a_, r_, l_ = segment("atk", n, rng, 0.8)
        elif kind == "wave_sh": a_, r_, l_ = segment("atk", n, rng, 0.8, shifted=True)
        elif kind == "mix10": a_, r_, l_ = segment("atk", n, rng, 0.10)
        elif kind == "rare05": a_, r_, l_ = segment("atk", n, rng, 0.005, pool=rare_i)
        if kind.startswith("wave"): waves.append((t, t + n))
        bounds.append((kind, t, t + n))
        A.append(a_); r.append(r_); l.append(l_); t += n
    return np.concatenate(A), np.concatenate(r), np.concatenate(l), waves, bounds


def summarize(dec, lab, mode=None, alpha=None, waves=(), bounds=()):
    ben = lab == "BENIGN"; atk = ~ben
    o = dict(benign_drop=int(((dec == 2) & ben).sum()), benign_flag=int(((dec >= 1) & ben).sum()),
             n_benign=int(ben.sum()), n_attack=int(atk.sum()),
             attack_drop=int(((dec == 2) & atk).sum()), attack_flag=int(((dec >= 1) & atk).sum()),
             attack_miss=int(((dec == 0) & atk).sum()))
    o["far_drop"] = o["benign_drop"] / max(o["n_benign"], 1)
    o["drop_rate_attack"] = o["attack_drop"] / max(o["n_attack"], 1)
    o["flag_rate_attack"] = o["attack_flag"] / max(o["n_attack"], 1)
    o["decision_flips_per_1k"] = float((np.diff(dec) != 0).mean() * 1000)
    if mode is not None:
        sw = np.flatnonzero(np.diff(mode) != 0)
        o["mode_switches"] = int(len(sw))
        o["alpha_changes_per_1k"] = float((np.diff(alpha) != 0).mean() * 1000)
        delays, recs = [], []
        for (s0, s1) in waves:
            on = np.flatnonzero(mode[s0:s1] == 1)
            delays.append(int(on[0]) if len(on) else None)
            off = np.flatnonzero(mode[s1:] == 0)
            recs.append(int(off[0]) if len(off) else None)
        o["detection_delay"] = delays; o["recovery_time"] = recs
        fa = 0
        for kind, b0, b1 in bounds:      # regime false alarms inside pure benign segments
            if kind == "benign":
                m = mode[b0:b1]; fa += int(((np.diff(m) == 1)).sum() + (m[0] == 1 and b0 > 0 and mode[b0-1] == 0))
        o["regime_false_alarms"] = fa
    return o


reps = 20
reg_out, traces = {}, {}
for name, spec in REG.items():
    rows = {"ACT (proposed)": [], "CREF fixed-alpha": [], "Heuristic adaptive (prev. ACT)": []}
    for rep in range(reps):
        rg = np.random.RandomState(1000 + rep)
        A, r, l, waves, bounds = build_stream(spec, rg)
        o = act_run(A, A_b0, P, rg)
        rows["ACT (proposed)"].append(summarize(o["dec"], l, o["mode"], o["alpha"], waves, bounds))
        a_fix = P["abar"]
        dfix = np.where(A >= 1 / a_fix, 2, np.where(A >= 1 / min(1, P["rho"] * a_fix), 1, 0)).astype(np.int8)
        rows["CREF fixed-alpha"].append(summarize(dfix, l))
        h = heuristic_run(r)
        rows["Heuristic adaptive (prev. ACT)"].append(summarize(h["dec"], l))
        if rep == 0:
            traces[name] = dict(A=A, lab=l, alpha=o["alpha"], C=o["C"], mode=o["mode"], dec=o["dec"],
                                L=o["L"], hthr=h["thr"], hdec=h["dec"], r=r, waves=waves, bounds=bounds)
    agg = {}
    for meth, lst in rows.items():
        agg[meth] = {}
        for k in lst[0]:
            vals = [x[k] for x in lst]
            if isinstance(vals[0], list):
                flat = [v for x in vals for v in x if v is not None]
                agg[meth][k] = dict(mean=float(np.mean(flat)) if flat else None,
                                    sd=float(np.std(flat)) if flat else None,
                                    n_detected=len(flat), n_total=sum(len(x) for x in vals))
            else:
                agg[meth][k] = dict(mean=float(np.mean(vals)), sd=float(np.std(vals)))
    reg_out[name] = agg
    a = agg["ACT (proposed)"]; f = agg["CREF fixed-alpha"]; h = agg["Heuristic adaptive (prev. ACT)"]
    print(f"\n{name}: benign drops ACT {a['benign_drop']['mean']:.2f} | fixed {f['benign_drop']['mean']:.2f} | "
          f"heur {h['benign_drop']['mean']:.1f}   attack-drop% ACT {a['drop_rate_attack']['mean']*100:.2f} | "
          f"fixed {f['drop_rate_attack']['mean']*100:.2f} | heur {h['drop_rate_attack']['mean']*100:.2f}", flush=True)
    if "detection_delay" in a:
        print(f"   delay {a['detection_delay']['mean']} recovery {a['recovery_time']['mean']} "
              f"switches {a['mode_switches']['mean']:.2f} regimeFA {a['regime_false_alarms']['mean']:.2f}", flush=True)
res["regimes"] = reg_out
save_json(res, f"act_{tag}.json")
joblib.dump(traces, os.path.join(ART, f"act_traces_{tag}.joblib"))
print("done", flush=True)
