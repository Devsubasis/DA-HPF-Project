"""Latency / throughput / CPU / memory for: single XGBoost, 4-member soft voting,
CREF (members + conformal e-fusion), CREF+ACT (+ online conformal regime layer + bucket).
usage: python timing.py TAG VARIANT"""
import sys, os, platform, joblib, numpy as np, psutil
from common import *
from act import online_p
from sortedcontainers import SortedList

tag, variant = sys.argv[1], sys.argv[2]
d = np.load(os.path.join(ART, f"{variant}.npz"), allow_pickle=True)
s = np.load(os.path.join(ART, f"scores_{tag}.npz"), allow_pickle=True)
core = load_json(f"core_{tag}.json"); kap, lam = core["kappa"], np.array(core["lam"])
models = joblib.load(os.path.join(ART, f"models_{tag}.joblib"))
models["rf"].n_jobs = 1
for k in ("xgb",): models[k].set_params(n_jobs=1)
models["lgbm"].set_params(n_jobs=1)
refs = build_refs(s["S_cal"]); A_b0 = cref_E(refs, s["S_bag0"], kap, lam)
proc = psutil.Process(os.getpid())
X = d["Xte"]; rng = np.random.RandomState(5); N = 3000
ii = rng.choice(len(X), N, replace=False)


def one(k, x): return models[k].predict_proba(x)[:, 1]


def run(name, fn):
    lat = np.empty(N); c0 = proc.cpu_times(); w0 = time.perf_counter()
    for j, i in enumerate(ii):
        t = time.perf_counter(); fn(X[i:i + 1]); lat[j] = (time.perf_counter() - t) * 1e3
    wall = time.perf_counter() - w0; c1 = proc.cpu_times()
    cpu = ((c1.user - c0.user) + (c1.system - c0.system)) / wall * 100
    r = dict(p50=float(np.percentile(lat, 50)), p95=float(np.percentile(lat, 95)),
             p99=float(np.percentile(lat, 99)), mean=float(lat.mean()),
             flows_per_s_online=float(N / wall), cpu_pct_of_one_core=float(cpu),
             rss_mb=float(proc.memory_info().rss / 1e6))
    print(f"{name:28s} p50={r['p50']:.3f} p95={r['p95']:.3f} p99={r['p99']:.3f} ms  "
          f"{r['flows_per_s_online']:.0f} flows/s  cpu={cpu:.0f}%  rss={r['rss_mb']:.0f}MB", flush=True)
    return r


state = dict(bag=SortedList(A_b0.tolist()), C=0.0, L=10.0)


def cref_flow(x):
    S = np.array([[one(k, x)[0] for k in MODEL_ORDER]])
    return cref_E(refs, S, kap, lam)[0]


def cref_act_flow(x):
    a = cref_flow(x)
    alpha = min(7.5e-4, state["L"] + 1e-3); state["L"] = min(10.0, state["L"] + 1e-3 - alpha)
    dec = 2 if a >= 1 / alpha else 0
    p = online_p(state["bag"], a, rng.random_sample()); e = 0.1 * p ** (-0.9)
    state["C"] = e * max(state["C"], 1.0); state["bag"].add(a)
    return dec


for f in [lambda x: one("xgb", x), cref_flow]: f(X[:1])   # warm-up
res = dict(hardware=dict(cpu=platform.processor() or open("/proc/cpuinfo").read().split("model name")[1].split("\n")[0].strip(": "),
                         logical_cores=psutil.cpu_count(), ram_gb=round(psutil.virtual_memory().total / 1e9, 1),
                         os=f"{platform.system()} {platform.release()}", python=platform.python_version(),
                         gpu="none (CPU-only)", inference_threads=1),
           online={}, batch={})
res["online"]["XGBoost (single)"] = run("XGBoost (single)", lambda x: one("xgb", x))
res["online"]["Soft voting (4 members)"] = run("Soft voting (4 members)", lambda x: np.mean([one(k, x) for k in MODEL_ORDER]))
res["online"]["CREF (4 members + fusion)"] = run("CREF (4 members + fusion)", cref_flow)
res["online"]["CREF + ACT (full DA-HPF)"] = run("CREF + ACT (full DA-HPF)", cref_act_flow)
# batch throughput
B = X[:100000]
for k in MODEL_ORDER:
    if k == "rf": models[k].n_jobs = 2
    else: models[k].set_params(n_jobs=2) if k != "cat" else None
t = time.perf_counter(); Sb = score_matrix(models, B); tm = time.perf_counter() - t
t = time.perf_counter(); Eb = cref_E(refs, Sb, kap, lam); tf = time.perf_counter() - t
t = time.perf_counter(); models["xgb"].predict_proba(B); tx = time.perf_counter() - t
bag = SortedList(A_b0.tolist()); taus = rng.random_sample(len(Eb)); t = time.perf_counter()
for j in range(20000):
    p = online_p(bag, Eb[j], taus[j]); bag.add(Eb[j])
ta = (time.perf_counter() - t) / 20000 * len(Eb)
res["batch"] = dict(n=len(B), xgb_flows_per_s=len(B) / tx, members_flows_per_s=len(B) / tm,
                    fusion_only_flows_per_s=len(B) / tf, act_regime_layer_flows_per_s=len(B) / ta,
                    cref_total_flows_per_s=len(B) / (tm + tf), cref_act_total_flows_per_s=len(B) / (tm + tf + ta),
                    model_disk_mb={k: os.path.getsize(os.path.join(ART, f"models_{tag}.joblib")) / 1e6 for k in ["all4"]},
                    refs_mb=sum(r.nbytes for r in refs) / 1e6)
print(res["batch"], flush=True)
save_json(res, f"timing_{tag}.json")
