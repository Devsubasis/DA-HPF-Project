# DA-HPF: Adaptive Packet Filtering with Provably Bounded False Alarms

Reproducibility code for the paper *"DA-HPF: Real-Time Adaptive Packet Filtering With Class-Robust E-Value Ensemble Fusion and Finite-Sample False-Alarm Guarantees"* (S. Mallick and P. Sujatha, Pondicherry University).

DA-HPF is a packet-filtering decision layer built in two parts:

- **CREF (class-robust e-value fusion)** fuses four cost-sensitive tree ensembles into one conformal e-value. The fused evidence keeps its false-alarm level under arbitrary dependence among the models.
- **ACT (adaptive conformal triage)** adapts the decision level. Expected false drops are bounded by a budget, and false regime alarms are controlled at all times through Ville's inequality.

## Requirements

- Python 3.10 or later, CPU only (no GPU needed).
- Install the dependencies:
  ```bash
  pip install -r requirements.txt
  ```

## Data

Download the datasets and put the CSV files in `./data`, or set `DAHPF_DATA=/path/to/folder`.

| Dataset | Files |
|---|---|
| CICIDS2017 (MachineLearningCVE) | `Friday-WorkingHours-Afternoon-DDos.pcap_ISCX.csv`, `Friday-WorkingHours-Afternoon-PortScan.pcap_ISCX.csv`, `Friday-WorkingHours-Morning.pcap_ISCX.csv` |
| UNSW-NB15 (official partition) | `UNSW_NB15_training-set.csv`, `UNSW_NB15_testing-set.csv` |

Renamed copies such as `..._pcap_ISCX.csv` or `...-set_in_.csv` are also recognised.

## Reproduce everything

```bash
bash run_all.sh
```

This takes about 3–4 hours on a 2-core CPU. Outputs go to three folders:

- `figs/`: every figure as a vector PDF and a 600-dpi PNG;
- `res/`: every result as JSON, plus `TABLES.md` with all paper tables;
- `art/`: intermediate data splits, models and scores.

Every step uses `seed = 42`.

## Protocol (leakage-free)

1. The data are split into Train and Test. CICIDS2017 uses a stratified 70/30 split; UNSW-NB15 uses its official partition.
2. Train is split into Fit and Validation.
3. Validation is split into three **pairwise disjoint** parts:
   - **TUNE**: all validation attacks plus 30% of the validation benign flows. It is used to choose the fusion weights (κ, λ).
   - **CAL**: 55% of the validation benign flows. These become the frozen conformal references.
   - **BAG0**: the remaining 15%. It seeds the ACT regime detector.
4. Feature selection, scaling and member training use **Fit only**. The Test set is used once, for reporting.

## Files

| File | Purpose |
|---|---|
| `common.py` | Data loading, LogBot, models, CREF (conformal p-values, power calibrator, class-robust weights), attainability formulas |
| `prep.py` | Builds the leakage-free data variants: random, temporal and UNSW splits |
| `train.py` | Trains the four cost-sensitive members, with ablation options (`--drop-feat`, `--exclude`, `--w1`) |
| `eval_core.py` | Compares 19 methods at fixed α; produces guarantee curves and the miscalibration-invariance test |
| `act.py`, `act_experiments.py` | ACT (budgeted per-flow level, online conformal e-detector); validity checks and six streaming regimes |
| `cv.py`, `stats.py` | 10-fold cross-validation with the full protocol inside each fold; Friedman, exact Wilcoxon, Holm correction, effect sizes, Nemenyi |
| `robustness.py` | Feature noise, missing features, attack-prevalence shift |
| `timing.py` | Per-flow P50/P95/P99 latency, batch throughput, memory |
| `analysis.py` | XGBoost convergence, calibration, SHAP, member dependence, PCA and t-SNE |
| `extra_models.py`, `label_conflict.py`, `matched_far.py` | AdaBoost baseline, label-conflict error analysis, matched-FAR analysis |
| `figs_*.py`, `summary.py` | All figures and tables |

## Hardware used in the paper

Intel Xeon (2.8 GHz, 2 cores), 7.3 GB RAM, no GPU, Python 3.12, scikit-learn 1.9.1, XGBoost 3.4.1, LightGBM 4.7.0, CatBoost 1.2.10, SHAP 0.52.0.

## Citation

If you use this code, please cite the paper (full reference to be added on publication).
