"""Regenerated versions of the figures already in the manuscript (new protocol) + diagrams."""
import numpy as np
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from sklearn.metrics import (roc_curve, precision_recall_curve, accuracy_score, precision_score,
                             recall_score, f1_score, matthews_corrcoef, roc_auc_score)
from common import *
plt = style()

DS = {"cic": "CICIDS2017", "unsw": "UNSW-NB15"}
ALPHA = {"cic": 1e-3, "unsw": 1e-2}
core = {t: load_json(f"core_{t}.json") for t in DS}
ev = {t: np.load(os.path.join(ART, f"evid_{t}.npz"), allow_pickle=True) for t in DS}
prep = {t: load_json(f"prep_{t}.json") for t in DS}
an = {t: load_json(f"analysis_{t}.json") for t in DS}


def nice(c): return {"DDOS": "DDoS", "PORTSCAN": "PortScan", "DOS": "DoS", "BENIGN": "Benign"}.get(c, c.title())


# ================================================================ diagrams
def box(ax, x, y, w, h, title, sub="", fc="white", ec="k", lw=0.8, bold=True, fs=7.2, dashed=False):
    p = FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.004,rounding_size=0.012", fc=fc, ec=ec, lw=lw,
                       ls="--" if dashed else "-")
    ax.add_patch(p)
    ax.text(x + w / 2, y + h * (0.62 if sub else 0.5), title, ha="center", va="center", fontsize=fs,
            fontweight="bold" if bold else "normal")
    if sub: ax.text(x + w / 2, y + h * 0.28, sub, ha="center", va="center", fontsize=fs - 1.3, color="0.25")


def arrow(ax, x0, y0, x1, y1, ls="-", col="k"):
    ax.add_patch(FancyArrowPatch((x0, y0), (x1, y1), arrowstyle="-|>", mutation_scale=7, lw=0.7, color=col, ls=ls))


fig, ax = plt.subplots(figsize=(7.0, 4.9)); ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")
G = "#F2F2F2"; H = "#E6EEF7"; R = "#FBE9E2"
box(ax, 0.01, 0.875, 0.215, 0.105, "Network flows", "CICIDS2017, UNSW-NB15,\nlive capture", fc=G, fs=7)
box(ax, 0.265, 0.875, 0.215, 0.105, "Feature selection", "top-25 RF importance\n(Fit split only)", fs=7)
box(ax, 0.52, 0.875, 0.215, 0.105, "LogBot + Z-score", r"$x'=\log(1+|x|)$" + "\n" + r"$\mu,\sigma$ from Fit", fs=7)
box(ax, 0.775, 0.875, 0.215, 0.105, "Cost-sensitive members", "RF, XGBoost, LightGBM,\nCatBoost ($W_R$ = 30)", fs=7)
for x0, x1 in [(0.225, 0.265), (0.48, 0.52), (0.735, 0.775)]: arrow(ax, x0, 0.927, x1, 0.927)
ax.add_patch(FancyBboxPatch((0.01, 0.405), 0.98, 0.42, boxstyle="round,pad=0.004,rounding_size=0.012", fc=H, ec="k", lw=1.0))
ax.text(0.025, 0.80, "CREF: class-robust e-value fusion (frozen calibration)", fontsize=7.6, fontweight="bold", va="center")
box(ax, 0.03, 0.60, 0.215, 0.15, "Conformal p-values", r"$u_k=\frac{1+\#\{b\in B_k:\,b\geq s_k\}}{n_b+1}$", fs=7)
box(ax, 0.275, 0.60, 0.215, 0.15, "Power calibrator", r"$E_k=\kappa\,u_k^{\kappa-1}$", fs=7)
box(ax, 0.52, 0.60, 0.215, 0.15, "Arithmetic e-merging", r"$E=\sum_k\lambda_k E_k$", fs=7)
box(ax, 0.765, 0.60, 0.21, 0.15, "Attainability", r"$1/\alpha\leq\kappa(n_b+1)^{1-\kappa}$", fs=7)
for x0, x1 in [(0.245, 0.275), (0.49, 0.52), (0.735, 0.765)]: arrow(ax, x0, 0.675, x1, 0.675)
box(ax, 0.03, 0.43, 0.215, 0.12, r"References $B_k$", "CAL split (benign),\nfrozen at deployment", fs=6.8)
box(ax, 0.275, 0.43, 0.46, 0.12, r"Class-robust weights $(\kappa^*,\lambda^*)$ (TUNE split)",
    r"$\arg\max_{\lambda,\kappa}\ \min_c\ |V_c|^{-1}\sum_{z\in V_c}\log E(z)$", fs=6.8)
box(ax, 0.765, 0.43, 0.21, 0.12, "Rank budget", r"$r(\alpha)=\lfloor(n_b+1)(\kappa\alpha)^{\frac{1}{1-\kappa}}\rfloor-1$", fs=6.4)
arrow(ax, 0.1375, 0.55, 0.1375, 0.60); arrow(ax, 0.3825, 0.55, 0.3825, 0.60); arrow(ax, 0.6275, 0.55, 0.6275, 0.60)
arrow(ax, 0.8825, 0.875, 0.8825, 0.75)
ax.add_patch(FancyBboxPatch((0.01, 0.105), 0.98, 0.255, boxstyle="round,pad=0.004,rounding_size=0.012", fc=R, ec="k", lw=1.0))
ax.text(0.025, 0.335, "ACT: adaptive conformal triage (two layers with guarantees)", fontsize=7.6, fontweight="bold", va="center")
box(ax, 0.03, 0.125, 0.29, 0.17, "Per-flow triage", "DROP: $E\\geq1/\\alpha_t$\nMONITOR: $E\\geq1/(\\rho\\alpha_t)$", fs=7)
box(ax, 0.355, 0.125, 0.29, 0.17, "Predictable level, token bucket",
    "$\\alpha_t\\leq L_{t-1}+\\bar\\alpha$\n$\\mathbb{E}[\\mathrm{FD}_T]\\leq\\bar\\alpha T+L_0$", fs=7)
box(ax, 0.68, 0.125, 0.295, 0.17, "Regime e-detector", "online $p_t$, $C_t=e_t\\max(C_{t-1},1)$\nARL $\\geq1/\\alpha_{reg}$ (Ville)", fs=7)
arrow(ax, 0.68, 0.21, 0.645, 0.21); arrow(ax, 0.355, 0.21, 0.32, 0.21)
arrow(ax, 0.6275, 0.405, 0.6275, 0.36)
box(ax, 0.03, 0.01, 0.215, 0.07, "ALLOW / MONITOR / DROP", fc=G, fs=6.4)
box(ax, 0.29, 0.01, 0.30, 0.07, "Dashboard (gRPC, Next.js)", "evidence, levels, regime state", fc=G, fs=6.6)
box(ax, 0.635, 0.01, 0.34, 0.07, "Kernel enforcement (eBPF/XDP)", "future work, not evaluated", fc="white", fs=6.6, dashed=True)
arrow(ax, 0.1375, 0.125, 0.1375, 0.08); arrow(ax, 0.245, 0.045, 0.29, 0.045); arrow(ax, 0.59, 0.045, 0.635, 0.045, ls="--", col="0.4")
savefig(fig, "P01_architecture_DA-HPF")

# ---- leakage-free protocol
fig, ax = plt.subplots(figsize=(7.0, 2.9)); ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")
pc = prep["cic"]; pu = prep["unsw"]
box(ax, 0.01, 0.40, 0.14, 0.20, "Dataset D", f"CIC: {pc['n_train']+pc['n_test']:,}\nUNSW: {pu['n_train']+pu['n_test']:,}", fc=G)
box(ax, 0.21, 0.66, 0.15, 0.20, "Train", "CIC 70% (strat.)\nUNSW official train")
box(ax, 0.21, 0.12, 0.15, 0.20, "Test (untouched)", f"CIC {pc['n_test']:,}\nUNSW {pu['n_test']:,}", fc=R)
box(ax, 0.42, 0.76, 0.20, 0.19, "Fit", f"CIC {pc['n_fit']:,}; UNSW {pu['n_fit']:,}\nfeatures, scaler, members", fs=6.6)
box(ax, 0.42, 0.48, 0.20, 0.17, "Validation", f"CIC {pc['n_val']:,}\nUNSW {pu['n_val']:,}", fs=6.6)
box(ax, 0.665, 0.70, 0.325, 0.16, r"TUNE: select $(\kappa^*,\lambda^*)$",
    f"val. attacks + 30% val. benign\n(CIC {pc['n_tune']:,}; UNSW {pu['n_tune']:,})", fs=6.6, fc=H)
box(ax, 0.665, 0.48, 0.325, 0.16, r"CAL: references $B_k$ ($n_b$)", f"55% val. benign\n(CIC {pc['n_cal']:,}; UNSW {pu['n_cal']:,})",
    fs=6.6, fc=H)
box(ax, 0.665, 0.26, 0.325, 0.16, r"BAG0: initial bag of ACT detector", f"15% val. benign\n(CIC {pc['n_bag0']:,}; UNSW {pu['n_bag0']:,})",
    fs=6.6, fc=H)
arrow(ax, 0.15, 0.55, 0.21, 0.74); arrow(ax, 0.15, 0.45, 0.21, 0.24)
arrow(ax, 0.36, 0.80, 0.42, 0.85); arrow(ax, 0.36, 0.72, 0.42, 0.57)
arrow(ax, 0.62, 0.59, 0.665, 0.77); arrow(ax, 0.62, 0.56, 0.665, 0.56); arrow(ax, 0.62, 0.53, 0.665, 0.34)
ax.text(0.40, 0.17, "Test is used once, for reporting only: no feature selection, scaling, hyper-parameter,\n"
        r"$(\kappa,\lambda)$, reference or threshold is fitted on it. TUNE, CAL and BAG0 are pairwise disjoint.",
        fontsize=6.6, va="center")
savefig(fig, "P01b_leakage_free_protocol")

# ================================================================ feature importance (Fit only)
fig, axs = plt.subplots(1, 2, figsize=(7.0, 3.6))
for j, t in enumerate(DS):
    imp = prep[t]["importance"]; top = list(imp.items())[:15][::-1]; ax = axs[j]
    v = np.array([x[1] for x in top]); v = v / sum(imp.values()) * 100
    ax.barh(range(len(top)), v, color=C["blue"], height=0.7)
    ax.set_yticks(range(len(top))); ax.set_yticklabels([x[0] for x in top], fontsize=6.5)
    for i, vi in enumerate(v): ax.text(vi + 0.2, i, f"{vi:.1f}", va="center", fontsize=6)
    ax.set_xlabel("RF impurity importance (%) on Fit split"); ax.set_title(f"({'ab'[j]}) {DS[t]}: top-15 of the 25 selected")
fig.tight_layout(); savefig(fig, "P02_feature_importance_fit_only")

# ================================================================ confusion matrices (CREF at alpha)
fig, axs = plt.subplots(1, 3, figsize=(7.0, 2.6), gridspec_kw=dict(width_ratios=[1, 1, 1.25]))
for j, t in enumerate(DS):
    r = core[t]["at_alpha"][str(ALPHA[t])]["CREF (proposed)"]; ax = axs[j]
    M = np.array([[r["tn"], r["fp"]], [r["fn"], r["tp"]]]); Mn = M / M.sum(1, keepdims=True)
    ax.imshow(Mn, cmap="Blues", vmin=0, vmax=1)
    for a in range(2):
        for b in range(2):
            ax.text(b, a, f"{M[a, b]:,}\n({Mn[a, b]*100:.3f}%)", ha="center", va="center", fontsize=6.6,
                    color="white" if Mn[a, b] > 0.6 else "k")
    ax.set_xticks([0, 1]); ax.set_yticks([0, 1]); ax.set_xticklabels(["pred. benign", "pred. attack"], fontsize=6.8)
    ax.set_yticklabels(["benign", "attack"], fontsize=6.8)
    ax.set_title(f"({'ab'[j]}) {DS[t]}: CREF, $\\alpha$={ALPHA[t]:g}", fontsize=7.5)
ax = axs[2]
pc_ = core["cic"]["at_alpha"]["0.001"]; pu_ = core["unsw"]["at_alpha"]["0.01"]
rows = [("CIC " + nice(c), pc_["CREF (proposed)"]["per_class"][c], pc_["XGBoost"]["per_class"][c]) for c in ["DDOS", "PORTSCAN", "BOT"]] + \
       [("UNSW " + nice(c), pu_["CREF (proposed)"]["per_class"][c], pu_["XGBoost"]["per_class"][c])
        for c in sorted(pu_["CREF (proposed)"]["per_class"], key=lambda c: -pu_["CREF (proposed)"]["per_class"][c])]
yy = np.arange(len(rows))[::-1]
ax.barh(yy + 0.2, [r_[1] * 100 for r_ in rows], 0.4, color=C["verm"], label="CREF (guaranteed $\\alpha$)")
ax.barh(yy - 0.2, [r_[2] * 100 for r_ in rows], 0.4, color=C["blue"], label="XGBoost (CAL quantile)")
ax.set_yticks(yy); ax.set_yticklabels([r_[0] for r_ in rows], fontsize=6); ax.set_xlabel("per-class recall (%)")
ax.set_title("(c) per-class recall", fontsize=7.5); ax.set_xlim(0, 100)
ax.legend(fontsize=5.8, loc="upper center", bbox_to_anchor=(0.45, -0.2), ncol=2)
fig.tight_layout(); savefig(fig, "P03_confusion_and_per_class")

# ================================================================ model comparison (dot plot) and overall line chart
ada = {t: np.load(os.path.join(ART, f"ada_{t}.npz")) for t in DS}


def ada_metrics(t):
    y = ev[t]["yte"]; a = ALPHA[t]; thr = np.quantile(ada[t]["cal"], 1 - a, method="higher")
    yh = (ada[t]["te"] > thr).astype(int)
    return dict(acc=accuracy_score(y, yh), prec=precision_score(y, yh, zero_division=0), rec=recall_score(y, yh),
                f1=f1_score(y, yh), macro_f1=f1_score(y, yh, average="macro"), mcc=matthews_corrcoef(y, yh),
                far=float(yh[y == 0].mean()), roc_auc=roc_auc_score(y, ada[t]["te"]))


meths = ["RF", "AdaBoost", "XGBoost", "LightGBM", "CatBoost", "Soft voting", "Stacking (LR)", "CREF (proposed)"]
fig, axs = plt.subplots(2, 4, figsize=(7.0, 4.2))
mets = [("macro_f1", "Macro-F1 (%)"), ("mcc", "MCC (%)"), ("rec", "TPR / recall (%)"), ("far", "FAR (%, log)")]
for j, t in enumerate(DS):
    r = dict(core[t]["at_alpha"][str(ALPHA[t])]); r["AdaBoost"] = ada_metrics(t)
    for i, (k, lbl) in enumerate(mets):
        ax = axs[j, i]; vals = [r[m][k] * 100 for m in meths]
        cols = [C["verm"] if "CREF" in m else "0.35" for m in meths]
        ax.hlines(range(len(meths)), 0 if k != "far" else 1e-4, vals, color="0.85", lw=0.8)
        ax.scatter(vals, range(len(meths)), color=cols, s=14, zorder=3)
        if k == "far": ax.set_xscale("log"); ax.set_xlim(1e-4, max(vals) * 3)
        else: ax.set_xlim(min(vals) - (max(vals) - min(vals)) * 0.25 - 0.01, max(vals) + (max(vals) - min(vals)) * 0.25 + 0.01)
        ax.set_yticks(range(len(meths))); ax.set_yticklabels(meths if i == 0 else [], fontsize=6.3)
        ax.set_xlabel(lbl, fontsize=7); ax.tick_params(axis="x", labelsize=6)
        if i == 0: ax.set_title(f"{DS[t]} ($\\alpha$={ALPHA[t]:g})", fontsize=7.5, loc="left")
fig.tight_layout(); savefig(fig, "P04_model_comparison_dotplot")

fig, axs = plt.subplots(1, 2, figsize=(7.0, 2.8))
mm = [("acc", "Accuracy"), ("prec", "Precision"), ("rec", "Recall"), ("f1", "F1-score"), ("mcc", "MCC")]
sty = {"RF": (C["green"], "o", "-"), "AdaBoost": (C["orange"], "s", "--"), "XGBoost": (C["blue"], "^", "-."),
       "Soft voting": (C["pink"], "v", ":"), "CREF (proposed)": (C["verm"], "D", "-")}
for j, t in enumerate(DS):
    r = dict(core[t]["at_alpha"][str(ALPHA[t])]); r["AdaBoost"] = ada_metrics(t); ax = axs[j]
    tf = core[t]["threshold_free"]
    for m, (col, mk, ls) in sty.items():
        vals = [r[m][k] * 100 for k, _ in mm] + [(tf[m]["roc_auc"] if m != "AdaBoost" else r[m]["roc_auc"]) * 100]
        ax.plot(range(6), vals, ls=ls, marker=mk, color=col, ms=4, lw=1.6 if "CREF" in m else 1.1, label=m)
        if "CREF" in m:
            for x_, v in enumerate(vals): ax.annotate(f"{v:.2f}", (x_, v), xytext=(0, 5), textcoords="offset points",
                                                     ha="center", fontsize=5.8, color=col)
    ax.set_xticks(range(6)); ax.set_xticklabels([x[1] for x in mm] + ["ROC-AUC"], fontsize=7, rotation=20)
    ax.set_ylabel("performance (%)"); ax.grid(True, axis="y"); ax.set_title(f"({'ab'[j]}) {DS[t]}, $\\alpha$={ALPHA[t]:g}")
    ax.legend(fontsize=6, loc="lower left")
fig.tight_layout(); savefig(fig, "P14_overall_comparison_six_metrics")

# ================================================================ XGBoost convergence
for key, ylabel, name in [("acc", "accuracy (%)", "P05_xgb_accuracy_convergence"),
                          ("logloss", "log loss", "P06_xgb_logloss_convergence")]:
    fig, axs = plt.subplots(1, 2, figsize=(7.0, 2.5))
    for j, t in enumerate(DS):
        cv = an[t]["convergence"]; ax = axs[j]
        tr = np.array(cv[f"train_{key}"]); va = np.array(cv[f"val_{key}"])
        if key == "acc": tr, va = tr * 100, va * 100
        it = np.arange(1, len(va) + 1)
        ax.plot(it, tr, color=C["blue"], lw=1.2, label="Fit (training subset)")
        ax.plot(it, va, color=C["verm"], lw=1.2, ls="--", label="TUNE (held-out validation)")
        if key == "logloss": ax.set_yscale("log")
        ax.set_xlabel("boosting iterations"); ax.set_ylabel(ylabel); ax.set_title(f"({'ab'[j]}) {DS[t]}")
        ax.legend(fontsize=6.5); ax.grid(True)
    fig.tight_layout(); savefig(fig, name)

# ================================================================ miscalibration robustness
fig, axs = plt.subplots(1, 2, figsize=(7.0, 2.6))
for j, t in enumerate(DS):
    mc = core[t]["miscalibration"]; g = ["0.25", "0.5", "1.0", "2.0", "3.0"]; ax = axs[j]
    far = [mc["results"][x]["vote_far"] * 100 for x in g]
    ax.plot([float(x) for x in g], far, "o-", color=C["blue"], label="soft voting: FAR at fixed deployed threshold")
    cref_far = core[t]["at_alpha"][str(mc["alpha"])]["CREF (proposed)"]["far"] * 100
    ax.plot([float(x) for x in g], [cref_far] * 5, "D-", color=C["verm"],
            label=f"CREF: identical scores (max |$\\Delta E$|=0)")
    ax.axhline(mc["alpha"] * 100, color="k", lw=0.7, ls=":", label=f"target $\\alpha$={mc['alpha']:g}")
    ax.set_xscale("log"); ax.set_xticks([0.25, 0.5, 1, 2, 3]); ax.set_xticklabels(["0.25", "0.5", "1", "2", "3"])
    ax.set_xlabel(r"CatBoost miscalibration $g(p)=p^{\gamma}$, $\gamma$"); ax.set_ylabel("benign FAR (%)")
    ax.set_title(f"({'ab'[j]}) {DS[t]}"); ax.legend(fontsize=6); ax.grid(True)
    print(t, "miscalibration identical:", {x: mc["results"][x]["cref_identical"] for x in g})
fig.tight_layout(); savefig(fig, "P07_miscalibration_invariance")

# ================================================================ ROC + PR
fig, axs = plt.subplots(2, 2, figsize=(7.0, 5.0))
for j, t in enumerate(DS):
    e = ev[t]; y = e["yte"]
    sc = [("CREF (proposed)", e["E"], C["verm"], "-"), ("Soft voting", e["soft"], C["blue"], "--"),
          ("Stacking (LR)", e["stack"], C["green"], "-."), ("Uniform e-mean", e["E_uni"], C["pink"], ":")]
    for nm, s, col, ls in sc:
        f_, t_, _ = roc_curve(y, s); auc = roc_auc_score(y, s)
        axs[0, j].plot(np.maximum(f_, 1e-6), t_, ls=ls, color=col, label=f"{nm} (AUC={auc:.5f})")
        p_, r_, _ = precision_recall_curve(y, s)
        axs[1, j].plot(r_, p_, ls=ls, color=col, label=f"{nm} (AP={core[t]['threshold_free'][nm]['pr_auc']:.4f})")
    axs[0, j].set_xscale("log"); axs[0, j].set_xlabel("false positive rate (log)"); axs[0, j].set_ylabel("true positive rate")
    axs[0, j].set_title(f"({'ab'[j]}) {DS[t]}: ROC"); axs[0, j].legend(fontsize=5.8, loc="lower right"); axs[0, j].grid(True)
    axs[1, j].set_xlabel("recall"); axs[1, j].set_ylabel("precision"); axs[1, j].set_title(f"({'cd'[j]}) {DS[t]}: precision-recall")
    axs[1, j].legend(fontsize=5.8, loc="lower left"); axs[1, j].grid(True)
    if t == "cic": axs[1, j].set_ylim(0.97, 1.001); axs[1, j].set_xlim(0.9, 1.001); axs[0, j].set_ylim(0.95, 1.001)
fig.tight_layout(); savefig(fig, "P10_ROC_PR_curves")

# ================================================================ calibration reliability
fig, axs = plt.subplots(1, 2, figsize=(7.0, 2.7))
for j, t in enumerate(DS):
    ax = axs[j]; ax.plot([0, 1], [0, 1], color="k", lw=0.7, ls=":")
    for k, mk in zip(MODEL_ORDER, ["o", "s", "^", "D"]):
        c = an[t]["calibration"][MODEL_NAME[k]]
        xs = [a for a, n in zip(c["conf"], c["count"]) if n > 0]; ys = [a for a, n in zip(c["acc"], c["count"]) if n > 0]
        ax.plot(xs, ys, marker=mk, ms=3, color=MCOL[k], lw=1, label=f"{MODEL_NAME[k]} (ECE={c['ece']:.4f}, Brier={c['brier']:.4f})")
    ax.set_xlabel("mean predicted attack probability"); ax.set_ylabel("observed attack frequency")
    ax.set_title(f"({'ab'[j]}) {DS[t]}: member reliability"); ax.legend(fontsize=5.6, loc="upper left"); ax.grid(True)
fig.tight_layout(); savefig(fig, "N17_member_calibration_reliability")
print("paper figs done")
