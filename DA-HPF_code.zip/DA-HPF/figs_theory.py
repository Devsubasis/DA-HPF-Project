"""Theory / fusion figures: attainability (2D+3D), guarantee validity, Fisher/Stouffer violation,
DET curves, class-robust simplex surface (3D + ternary), kappa selection, member dependence,
evidence distributions, kappa x alpha sensitivity."""
import numpy as np
from sklearn.metrics import roc_curve
from common import *
plt = style()
from mpl_toolkits.mplot3d import Axes3D  # noqa
from matplotlib.colors import LogNorm

DS = {"cic": "CICIDS2017", "unsw": "UNSW-NB15"}
core = {t: load_json(f"core_{t}.json") for t in DS}
ev = {t: np.load(os.path.join(ART, f"evid_{t}.npz"), allow_pickle=True) for t in DS}
ALPHA = {"cic": 1e-3, "unsw": 1e-2}

# ------------------------------------------------------------------ attainability 3D surface
fig = plt.figure(figsize=(7.0, 3.1))
ax = fig.add_subplot(1, 2, 1, projection="3d")
kap = np.linspace(0.03, 0.6, 60); nb = np.logspace(2, 6, 60)
KK, NN = np.meshgrid(kap, nb)
Z = np.log10(e_max(KK, NN))
ax.plot_surface(KK, np.log10(NN), Z, cmap="viridis", linewidth=0, antialiased=True, alpha=0.9, rcount=60, ccount=60)
ko = 1 / np.log(nb + 1)
ax.plot(ko, np.log10(nb), np.log10(e_max(ko, nb)), color=C["verm"], lw=1.6, label=r"$\kappa^{\circ}=1/\ln(n_b+1)$")
for t, mk in [("cic", "o"), ("unsw", "s")]:
    ax.scatter([core[t]["kappa"]], [np.log10(core[t]["n_b"])], [np.log10(core[t]["E_max"])], color="k", marker=mk, s=28,
               depthshade=False, label=f"{DS[t]} ($\\kappa^*$={core[t]['kappa']}, $n_b$={core[t]['n_b']:,})")
ax.set_xlabel(r"$\kappa$", labelpad=-2); ax.set_ylabel(r"$\log_{10} n_b$", labelpad=-2)
ax.set_zlabel(r"$\log_{10} E_{\max}$", labelpad=-2); ax.view_init(24, -128)
ax.tick_params(pad=-1); ax.set_title(r"(a) $E_{\max}=\kappa(n_b+1)^{1-\kappa}$")
ax.legend(loc="upper left", fontsize=6, bbox_to_anchor=(-0.05, 1.02))
ax2 = fig.add_subplot(1, 2, 2)
alphas = np.logspace(-5, -1, 60)
req = [nb_required(a) for a in alphas]
ax2.loglog(alphas, req, color=C["blue"], lw=1.6, label=r"required $n_b$ (optimal $\kappa$)")
for t, mk in [("cic", "o"), ("unsw", "s")]:
    ax2.axhline(core[t]["n_b"], color="0.4", lw=0.7, ls="--")
    ax2.plot(core[t]["alpha_min"], core[t]["n_b"], mk, color="k", ms=5)
    ax2.annotate(f"{DS[t]}: $\\alpha_{{\\min}}$={core[t]['alpha_min']:.1e}", (core[t]["alpha_min"], core[t]["n_b"]),
                 xytext=(6, 5) if t == "cic" else (-128, -12), textcoords="offset points", fontsize=7)
for a in [1e-2, 1e-3, 1e-4]:
    ax2.plot(a, nb_required(a), "^", color=C["verm"], ms=4)
    ax2.annotate(f"{nb_required(a):,}", (a, nb_required(a)), xytext=(4, -9), textcoords="offset points", fontsize=6.5)
ax2.set_xlabel(r"target false-alarm level $\alpha$"); ax2.set_ylabel(r"benign calibration size $n_b$")
ax2.set_title("(b) Calibration sizing rule"); ax2.grid(True, which="major"); ax2.legend(loc="upper right")
fig.tight_layout(); savefig(fig, "N01_attainability_surface_and_sizing")

# ------------------------------------------------------------------ E_max vs kappa (2D)
fig, ax = plt.subplots(figsize=(3.5, 2.6))
kk = np.linspace(0.02, 0.8, 300)
for t, ls in [("cic", "-"), ("unsw", "--")]:
    n = core[t]["n_b"]; ax.semilogy(kk, e_max(kk, n), ls, color="k", lw=1.2, label=f"{DS[t]} ($n_b$={n:,})")
    k0 = kappa_opt(n); ax.plot(k0, e_max(k0, n), "o", color=C["verm"], ms=4)
    ax.plot(core[t]["kappa"], e_max(core[t]["kappa"], n), "x", color=C["blue"], ms=6, mew=1.4)
for a, lbl in [(1e-2, r"$1/\alpha=10^2$"), (1e-3, r"$1/\alpha=10^3$")]:
    ax.axhline(1 / a, color=C["gray"], lw=0.7, ls=":"); ax.text(0.62, 1 / a * 1.12, lbl, fontsize=7)
ax.plot([], [], "o", color=C["verm"], ms=4, label=r"$\kappa^{\circ}=1/\ln(n_b+1)$")
ax.plot([], [], "x", color=C["blue"], ms=6, mew=1.4, label=r"selected $\kappa^*$")
ax.set_xlabel(r"calibrator shape $\kappa$"); ax.set_ylabel(r"maximum attainable evidence $E_{\max}$")
ax.legend(fontsize=6.5, loc="lower left"); ax.grid(True, which="major")
fig.tight_layout(); savefig(fig, "N02_Emax_vs_kappa")

# ------------------------------------------------------------------ guarantee validity (FAR vs alpha, TPR vs alpha)
meth = [("CREF (proposed)", C["verm"], "-", "o"), ("Uniform e-mean", C["blue"], "--", "s"),
        ("Bonferroni (K min u)", C["green"], "-.", "^"), ("Fisher (indep.)", C["pink"], ":", "D"),
        ("Stouffer (indep.)", C["orange"], ":", "v")]
fig, axs = plt.subplots(2, 2, figsize=(7.0, 5.0))
for j, t in enumerate(DS):
    g = core[t]["guarantee"]; a = np.array(g["CREF (proposed)"]["alpha"])
    amin = core[t]["alpha_min"]
    for i, ax in enumerate(axs[:, j]):
        ax.axvspan(a.min(), amin, color="0.92", zorder=0)
        for nm, col, ls, mk in meth:
            y = np.array(g[nm]["far" if i == 0 else "tpr"])
            if i == 0: y = np.maximum(y, 1e-6)
            ax.plot(a, y, ls=ls, color=col, marker=mk, ms=2.6, lw=1.1, label=nm.replace(" (K min u)", ""))
        ax.set_xscale("log")
        if i == 0:
            ax.plot(a, a, color="k", lw=0.9, label=r"bound $\alpha$"); ax.set_yscale("log")
            ax.set_ylabel("empirical benign FAR"); ax.set_ylim(8e-7, 1)
            ax.text(amin * 0.85, 2e-6, "unattainable\n" + r"($1/\alpha>E_{\max}$)", ha="right", fontsize=6.5, color="0.35")
            ax.set_title(f"({'ab'[j]}) {DS[t]}: false-alarm control")
        else:
            ax.set_ylabel("attack detection rate (TPR)"); ax.set_xlabel(r"target level $\alpha$")
            ax.set_title(f"({'cd'[j]}) {DS[t]}: detection at the same $\\alpha$")
        ax.grid(True, which="major")
axs[0, 0].legend(fontsize=6.2, loc="upper left", ncol=2)
fig.tight_layout(); savefig(fig, "N03_guarantee_validity_far_tpr")

# ------------------------------------------------------------------ FAR / alpha violation bar
fig, axs = plt.subplots(1, 2, figsize=(7.0, 2.7), sharey=True)
order = ["Fisher (indep.)", "Stouffer (indep.)", "RF", "XGBoost", "LightGBM", "CatBoost", "Soft voting",
         "Stacking (LR)", "Hard voting (>=2/4)", "Bonferroni (K min u)", "p-averaging (2 mean u)",
         "Conformal single (XGBoost)", "Uniform e-mean", "CREF (proposed)"]
for j, t in enumerate(DS):
    a = ALPHA[t]; r = core[t]["at_alpha"][str(a)]
    vals = [max(r[m]["far"], 1e-6) / a for m in order]
    cols = [C["pink"] if "indep" in m else (C["verm"] if "CREF" in m else
            (C["blue"] if ("e-mean" in m or "Conformal" in m or "Bonf" in m or "averag" in m) else "0.55")) for m in order]
    ax = axs[j]; y = np.arange(len(order))
    ax.barh(y, vals, color=cols, height=0.7, edgecolor="white", linewidth=0.6)
    ax.axvline(1, color="k", lw=0.9); ax.set_xscale("log")
    for yi, v in zip(y, vals): ax.text(v * 1.15, yi, f"{v:.3g}", va="center", fontsize=6)
    ax.set_yticks(y); ax.set_yticklabels([m.replace(" (K min u)", "").replace(" (2 mean u)", "") for m in order], fontsize=7)
    ax.set_xlabel(r"realized FAR / nominal $\alpha$  (log)"); ax.set_xlim(5e-3, 200)
    ax.set_title(f"({'ab'[j]}) {DS[t]}, $\\alpha$={a:g}")
fig.text(0.5, -0.02, "grey: empirical CAL-quantile threshold (no finite-sample guarantee); pink: independence-based "
         "p-value combination; blue/vermilion: valid under arbitrary dependence", ha="center", fontsize=6.5)
fig.tight_layout(); savefig(fig, "N04_far_over_alpha_violation")

# ------------------------------------------------------------------ DET / operating characteristic
fig, axs = plt.subplots(1, 2, figsize=(7.0, 2.9))
for j, t in enumerate(DS):
    e = ev[t]; y = e["yte"]; ax = axs[j]
    ad = load_json(f"core_{t}.json")
    curves = [("CREF (proposed)", e["E"], C["verm"], "-"), ("Soft voting", e["soft"], C["blue"], "--"),
              ("Stacking (LR)", e["stack"], C["green"], "-."), ("Uniform e-mean", e["E_uni"], C["pink"], ":")]
    for nm, sc, col, ls in curves:
        fpr, tpr, _ = roc_curve(y, sc)
        ok = fpr > 0
        ax.plot(fpr[ok], np.maximum(1 - tpr[ok], 1e-5), ls=ls, color=col, lw=1.2, label=nm)
    for a, mk in [(1e-2, "o"), (ALPHA[t], "s")] if t == "cic" else [(1e-2, "o"), (5e-3, "s")]:
        r = ad["at_alpha"][str(a)]["CREF (proposed)"]
        ax.plot(max(r["far"], 1e-6), max(r["fnr"], 1e-5), mk, color=C["verm"], ms=5, mfc="white", mew=1.2)
        ax.annotate(f"$\\alpha$={a:g}", (max(r["far"], 1e-6), r["fnr"]), xytext=(5, 3), textcoords="offset points", fontsize=6.5)
        rv = ad["at_alpha"][str(a)]["Soft voting"]
        ax.plot(rv["far"], max(rv["fnr"], 1e-5), mk, color=C["blue"], ms=5, mfc="white", mew=1.2)
    ax.set_xscale("log"); ax.set_yscale("log"); ax.set_xlim(1e-6 if t == "cic" else 1e-5, 1)
    ax.set_xlabel("false-alarm rate (benign)"); ax.set_ylabel("miss rate (attacks)")
    ax.set_title(f"({'ab'[j]}) {DS[t]} operating characteristic"); ax.grid(True, which="major")
    ax.legend(fontsize=6.5, loc="upper right" if t == "cic" else "lower left")
fig.tight_layout(); savefig(fig, "N05_DET_operating_characteristic")

# ------------------------------------------------------------------ class-robust objective over the simplex (3D + ternary)
def tune_E(t):
    s = np.load(os.path.join(ART, f"scores_{t}.npz"), allow_pickle=True)
    d = np.load(os.path.join(ART, f"{t}.npz"), allow_pickle=True)
    lt = d["ltune"]; St = s["S_tune"]; refs = build_refs(St[lt == "BENIGN"])
    U = conformal_u(refs, St); E = e_vals(U, core[t]["kappa"])
    cls = [c for c in np.unique(lt) if c != "BENIGN"]
    return [E[lt == c] for c in cls], cls


fig = plt.figure(figsize=(7.0, 5.6))
for j, t in enumerate(DS):
    Eb, cls = tune_E(t); lam = np.array(core[t]["lam"])
    drop = int(np.argmin(lam)); keep = [k for k in range(4) if k != drop]
    n = 70; pts, vals = [], []
    for i in range(n + 1):
        for jj in range(n + 1 - i):
            w = np.zeros(4); w[keep[0]] = i / n; w[keep[1]] = jj / n; w[keep[2]] = 1 - (i + jj) / n
            w = np.maximum(w, 0)
            v = min(np.mean(np.log(np.maximum(Ec @ w, 1e-300))) for Ec in Eb)
            pts.append((i / n, jj / n)); vals.append(v)
    pts = np.array(pts); vals = np.array(vals)
    # barycentric -> cartesian
    xs = pts[:, 1] + 0.5 * (1 - pts[:, 0] - pts[:, 1]); ys = (np.sqrt(3) / 2) * (1 - pts[:, 0] - pts[:, 1])
    ax = fig.add_subplot(2, 2, 1 + j, projection="3d")
    w1, w2 = pts[:, 1], 1 - pts[:, 0] - pts[:, 1]
    ax.plot_trisurf(w1, w2, vals, cmap="viridis", linewidth=0, antialiased=True)
    ws = lam[keep] / lam[keep].sum()
    xo, yo = ws[1] + 0.5 * ws[2], np.sqrt(3) / 2 * ws[2]
    vo = min(np.mean(np.log(Ec @ lam)) for Ec in Eb); vu = min(np.mean(np.log(Ec @ (np.ones(4) / 4))) for Ec in Eb)
    ax.scatter([ws[1]], [ws[2]], [vo], color=C["verm"], s=30, depthshade=False, label=r"$\lambda^*$ (max-min)")
    ax.set_title(f"({'ab'[j]}) {DS[t]}: worst-class log-evidence")
    ax.set_xlabel(f"$\\lambda_{{{MODEL_NAME[MODEL_ORDER[keep[1]]]}}}$", labelpad=-4, fontsize=7)
    ax.set_ylabel(f"$\\lambda_{{{MODEL_NAME[MODEL_ORDER[keep[2]]]}}}$", labelpad=-4, fontsize=7)
    ax.set_zlabel(r"$\min_c g_c(\lambda)$", labelpad=-4, fontsize=7); ax.tick_params(labelsize=6, pad=-2)
    ax.view_init(28, -120); ax.legend(fontsize=6, loc="upper left")
    ax2 = fig.add_subplot(2, 2, 3 + j)
    tc = ax2.tricontourf(xs, ys, vals, levels=18, cmap="viridis")
    ax2.tricontour(xs, ys, vals, levels=8, colors="white", linewidths=0.3)
    ax2.plot([0, 1, 0.5, 0], [0, 0, np.sqrt(3) / 2, 0], color="k", lw=0.6)
    ax2.plot(xo, yo, "o", color=C["verm"], ms=6, mec="white", label=r"$\lambda^*$ (class-robust)")
    ax2.plot(1 / 3 + 1 / 6, np.sqrt(3) / 6, "s", color="white", ms=5, mec="k", label="uniform (3 shown)")
    names = [MODEL_NAME[MODEL_ORDER[k]] for k in keep]
    ax2.text(-0.03, -0.06, names[0], fontsize=7, ha="center"); ax2.text(1.03, -0.06, names[1], fontsize=7, ha="center")
    ax2.text(0.5, np.sqrt(3) / 2 + 0.025, names[2], fontsize=7, ha="center", va="bottom")
    ax2.set_ylim(-0.1, np.sqrt(3) / 2 + 0.1)
    ax2.set_aspect("equal"); ax2.axis("off"); ax2.set_title(
        f"({'cd'[j]}) {DS[t]} simplex ({MODEL_NAME[MODEL_ORDER[drop]]} weight fixed at 0)", fontsize=8, pad=10)
    cb = fig.colorbar(tc, ax=ax2, fraction=0.04, pad=0.02); cb.ax.tick_params(labelsize=6)
    cb.set_label(r"$\min_c g_c$", fontsize=7)
    ax2.legend(fontsize=6, loc="upper right")
    print(t, "objective lambda*", vo, "uniform", vu)
fig.tight_layout(); savefig(fig, "N06_class_robust_simplex_3D_ternary")

# ------------------------------------------------------------------ kappa selection
fig, axs = plt.subplots(1, 2, figsize=(7.0, 2.5))
for j, t in enumerate(DS):
    g = core[t]["selection"]["grid"]; ks = [x["kappa"] for x in g]
    ax = axs[j]
    ax.plot(ks, [x["obj"] for x in g], "o-", color=C["verm"], label=r"class-robust $\lambda^*(\kappa)$")
    ax.plot(ks, [x["obj_uniform"] for x in g], "s--", color=C["blue"], label=r"uniform $\lambda$")
    ntb = load_json(f"prep_{t}.json")["n_tune_benign"]
    ax.axvline(kappa_opt(ntb), color="0.5", ls=":", lw=0.9,
               label=r"$\kappa^{\circ}=1/\ln(n_b+1)$ (attainability-optimal)")
    ax.set_xscale("log"); ax.set_xlabel(r"$\kappa$"); ax.set_ylabel("worst-class mean log-evidence (TUNE)")
    ax.set_title(f"({'ab'[j]}) {DS[t]}"); ax.grid(True); ax.legend(fontsize=6.3)
fig.tight_layout(); savefig(fig, "N07_kappa_selection")

# ------------------------------------------------------------------ member dependence
an = {t: load_json(f"analysis_{t}.json") for t in DS}
fig, axs = plt.subplots(1, 3, figsize=(7.0, 2.4), gridspec_kw=dict(width_ratios=[1, 1, 1.15]))
lbl = [MODEL_NAME[k] for k in MODEL_ORDER]
for j, t in enumerate(DS):
    M = np.array(an[t]["dependence"]["benign_spearman"]); ax = axs[j]
    im = ax.imshow(M, vmin=0, vmax=1, cmap="Blues")
    for a in range(4):
        for b in range(4): ax.text(b, a, f"{M[a, b]:.2f}", ha="center", va="center", fontsize=6.5,
                                   color="white" if M[a, b] > 0.6 else "k")
    ax.set_xticks(range(4)); ax.set_yticks(range(4)); ax.set_xticklabels(lbl, rotation=35, fontsize=6.5)
    ax.set_yticklabels(lbl, fontsize=6.5); ax.set_title(f"({'ab'[j]}) {DS[t]}: Spearman of $u_k$ (benign)", fontsize=7.5)
U = ev["cic"]["U"]; y = ev["cic"]["yte"]; rng = np.random.RandomState(1)
ib = rng.choice(np.where(y == 0)[0], 15000, replace=False); ia = rng.choice(np.where(y == 1)[0], 4000, replace=False)
ax = axs[2]
jit = lambda v: v * np.exp(rng.normal(0, 0.04, len(v)))
ax.scatter(jit(U[ib, 1]), jit(U[ib, 2]), s=1.2, color="0.55", alpha=0.35, rasterized=True, label="benign")
ax.scatter(jit(U[ia, 1]), jit(U[ia, 2]), s=1.2, color=C["verm"], alpha=0.35, rasterized=True, label="attack")
ax.set_xscale("log"); ax.set_yscale("log"); ax.set_xlabel(r"$u_{\mathrm{XGBoost}}$"); ax.set_ylabel(r"$u_{\mathrm{LightGBM}}$")
ax.set_title("(c) CICIDS2017 member p-values", fontsize=7.5); ax.legend(fontsize=6, markerscale=5, loc="lower right")
fig.tight_layout(); savefig(fig, "N08_member_dependence")

# ------------------------------------------------------------------ evidence distribution by class
fig, axs = plt.subplots(1, 2, figsize=(7.0, 2.6))
for j, t in enumerate(DS):
    e = ev[t]; lab = e["lte"]; E = e["E"]; ax = axs[j]
    bins = np.linspace(np.log10(E.min()) - 0.05, np.log10(core[t]["E_max"]) + 0.1, 70)
    cl = ["BENIGN"] + ([c for c in ["DDOS", "PORTSCAN", "BOT"]] if t == "cic" else ["GENERIC", "EXPLOITS", "FUZZERS", "WORMS"])
    cols = ["0.5", C["blue"], C["orange"], C["verm"], C["green"]]
    for c, col in zip(cl, cols):
        ax.hist(np.log10(E[lab == c]), bins=bins, histtype="step", lw=1.1, color=col, density=True,
                label={"DDOS": "DDoS", "PORTSCAN": "PortScan"}.get(c, c.title()))
    a = ALPHA[t]
    ax.axvline(np.log10(1 / a), color="k", lw=0.9, ls="--"); ax.axvline(np.log10(1 / (10 * a)), color="k", lw=0.7, ls=":")
    ax.axvline(np.log10(core[t]["E_max"]), color=C["verm"], lw=0.9)
    ax.text(np.log10(1 / a), ax.get_ylim()[1] * 0.0 + 0.9, " DROP", fontsize=6.5, transform=ax.get_xaxis_transform())
    ax.text(np.log10(1 / (10 * a)), 0.93, " MONITOR", fontsize=6.5, transform=ax.get_xaxis_transform())
    ax.text(np.log10(core[t]["E_max"]), 0.7, r" $E_{\max}$", fontsize=6.5, color=C["verm"], transform=ax.get_xaxis_transform())
    ax.set_yscale("log"); ax.set_xlabel(r"fused evidence $\log_{10} E(\mathbf{z})$"); ax.set_ylabel("density (log)")
    ax.set_title(f"({'ab'[j]}) {DS[t]}"); ax.legend(fontsize=6, loc="upper left", bbox_to_anchor=(0.0, 1.0) if t == "cic" else (0.0, 0.62))
fig.tight_layout(); savefig(fig, "N09_evidence_distribution_by_class")

# ------------------------------------------------------------------ sensitivity heatmap kappa x alpha
fig, axs = plt.subplots(2, 2, figsize=(7.0, 4.6))
ks = [0.05, 0.075, 0.1, 0.15, 0.2, 0.3, 0.5]; als = [1e-1, 5e-2, 2e-2, 1e-2, 5e-3, 2e-3, 1e-3, 5e-4]
for j, t in enumerate(DS):
    e = ev[t]; U = e["U"]; y = e["yte"]; lam = np.array(core[t]["lam"])
    TPR = np.full((len(ks), len(als)), np.nan); FAR = np.full_like(TPR, np.nan)
    for a_, k in enumerate(ks):
        E = e_vals(U, k) @ lam
        for b_, al in enumerate(als):
            if 1 / al <= e_max(k, core[t]["n_b"]):
                d_ = E >= 1 / al; TPR[a_, b_] = d_[y == 1].mean(); FAR[a_, b_] = d_[y == 0].mean()
    for i, (M, ttl, cm) in enumerate([(TPR, "TPR", "Greens"), (FAR, "FAR", "Reds")]):
        ax = axs[i, j]; im = ax.imshow(M, cmap=cm, aspect="auto")
        for a_ in range(len(ks)):
            for b_ in range(len(als)):
                v = M[a_, b_]
                ax.text(b_, a_, "n/a" if np.isnan(v) else (f"{v*100:.1f}" if ttl == "TPR" else f"{v*100:.3f}"),
                        ha="center", va="center", fontsize=5.4, color="0.4" if np.isnan(v) else "k")
        ax.set_xticks(range(len(als))); ax.set_xticklabels([f"{a:g}" for a in als], fontsize=6, rotation=30)
        ax.set_yticks(range(len(ks))); ax.set_yticklabels([str(k) for k in ks], fontsize=6.5)
        ax.set_xlabel(r"$\alpha$"); ax.set_ylabel(r"$\kappa$")
        ax.set_title(f"({'abcd'[2*i+j]}) {DS[t]}: {ttl} (%)  [n/a = unattainable]", fontsize=7.5)
fig.tight_layout(); savefig(fig, "N10_sensitivity_kappa_alpha")
print("theory figs done")
