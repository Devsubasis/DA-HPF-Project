#!/usr/bin/env bash
# Reproduces every result, table and figure of the paper.
# Place the datasets in ./data (or export DAHPF_DATA=/path/to/datasets) first.
set -euo pipefail
cd "$(dirname "$0")"

# 1. leakage-free data variants (Fit / TUNE / CAL / BAG0 / Test)
python prep.py cic cic_temporal unsw

# 2. members + core evaluation (main tables, guarantee curves, miscalibration)
python train.py cic  cic  --w1 && python eval_core.py cic  cic
python train.py unsw unsw --w1 && python eval_core.py unsw unsw

# 3. leakage audit: temporal split and Destination-Port ablation
python train.py cic_temporal cic_temporal && python eval_core.py cic_temporal cic_temporal
python train.py cic cic_nodport --drop-feat "Destination Port" && python eval_core.py cic_nodport cic

# 4. unseen attack classes (class removed from Fit and TUNE)
for c in BOT PORTSCAN DDOS; do
  python train.py cic  cic_ex_$c  --exclude $c && python eval_core.py cic_ex_$c  cic  $c; done
for c in WORMS SHELLCODE BACKDOOR DOS; do
  python train.py unsw unsw_ex_$c --exclude $c && python eval_core.py unsw_ex_$c unsw $c; done

# 5. AdaBoost baseline, SHAP / PCA / calibration, ACT, robustness, cost
python extra_models.py cic unsw
python analysis.py cic cic && python analysis.py unsw unsw
python act_experiments.py cic cic && python act_experiments.py unsw unsw
python robustness.py cic cic && python robustness.py unsw unsw
python timing.py cic cic
python label_conflict.py
python matched_far.py

# 6. 10-fold cross-validation (full protocol inside each fold) + statistics
python cv.py cic 0-9
python cv.py unsw 0-9
python stats.py

# 7. figures (PDF + 600-dpi PNG in ./figs) and tables (./res/TABLES.md)
python figs_theory.py
python figs_extra.py
python figs_embed.py
python figs_paper.py
python figs_shap.py
python figs_act.py
python figs_eval.py
python summary.py
echo "Done: figures in ./figs, tables in ./res/TABLES.md"
