"""Train the 4 cost-sensitive members on Fit and score all blocks.
usage: python train.py VARIANT TAG [--fast] [--drop-feat NAME] [--exclude CLASS] [--w1]"""
import sys, argparse, joblib, numpy as np
from common import *

ap = argparse.ArgumentParser()
ap.add_argument("variant"); ap.add_argument("tag")
ap.add_argument("--fast", action="store_true")
ap.add_argument("--drop-feat", default=None)
ap.add_argument("--exclude", default=None)
ap.add_argument("--w1", action="store_true", help="also train XGBoost without cost weights")
a = ap.parse_args()

d = np.load(os.path.join(ART, f"{a.variant}.npz"), allow_pickle=True)
ds = "unsw" if a.variant.startswith("unsw") else "cic"
feats = list(d["feats"])
cols = [i for i, f in enumerate(feats) if f != a.drop_feat]
Xfit, lfit = d["Xfit"][:, cols], d["lfit"]
blocks = {b: d[f"X{b}"][:, cols] for b in ["tune", "cal", "bag0", "te"]}
if a.exclude:  # unseen-attack protocol: class removed from Fit (and later from TUNE)
    keep = lfit != a.exclude
    Xfit, lfit = Xfit[keep], lfit[keep]
y = (lfit != "BENIGN").astype(int)
sw = rare_weights(lfit, ds)

models, times = {}, {}
for k, m in make_models(a.fast).items():
    t0 = time.time(); m.fit(Xfit, y, sample_weight=sw); times[k] = time.time() - t0
    models[k] = m
    print(f"[{a.tag}] {k} trained {times[k]:.0f}s", flush=True)
out = {f"S_{b}": score_matrix(models, X) for b, X in blocks.items()}
if a.w1:
    from xgboost import XGBClassifier
    m1 = make_models(a.fast)["xgb"]; t0 = time.time(); m1.fit(Xfit, y)
    times["xgb_w1"] = time.time() - t0
    for b, X in blocks.items():
        out[f"W1_{b}"] = m1.predict_proba(X)[:, 1]
    joblib.dump(m1, os.path.join(ART, f"xgbw1_{a.tag}.joblib"))
np.savez_compressed(os.path.join(ART, f"scores_{a.tag}.npz"), **out,
                    cols=np.array([feats[i] for i in cols]))
joblib.dump(models, os.path.join(ART, f"models_{a.tag}.joblib"))
save_json(dict(variant=a.variant, tag=a.tag, fast=a.fast, drop=a.drop_feat,
               exclude=a.exclude, train_s=times, n_fit=len(Xfit)), f"train_{a.tag}.json")
print(f"[{a.tag}] done", flush=True)
