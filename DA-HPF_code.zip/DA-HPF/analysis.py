"""Convergence, calibration, SHAP, member dependence, PCA/t-SNE embeddings.
usage: python analysis.py TAG VARIANT"""
import sys, joblib, numpy as np
from scipy.stats import spearmanr
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
from sklearn.metrics import brier_score_loss
from common import *

tag, variant = sys.argv[1], sys.argv[2]
ds = "unsw" if variant.startswith("unsw") else "cic"
alpha = 1e-3 if ds == "cic" else 1e-2
d = np.load(os.path.join(ART, f"{variant}.npz"), allow_pickle=True)
s = np.load(os.path.join(ART, f"scores_{tag}.npz"), allow_pickle=True)
core = load_json(f"core_{tag}.json"); kap, lam = core["kappa"], np.array(core["lam"])
models = joblib.load(os.path.join(ART, f"models_{tag}.joblib"))
feats = list(d["feats"]); refs = build_refs(s["S_cal"])
Xte, lte = d["Xte"], d["lte"]; yte = (lte != "BENIGN").astype(int)
Se = s["S_te"]; E = cref_E(refs, Se, kap, lam); U = conformal_u(refs, Se)
out = {}

# ---- XGBoost convergence (eval on TUNE = held-out validation)
from xgboost import XGBClassifier
ytune = (d["ltune"] != "BENIGN").astype(int)
mx = make_models()["xgb"]; mx.set_params(eval_metric=["error", "logloss"])
mx.fit(d["Xfit"], (d["lfit"] != "BENIGN").astype(int), sample_weight=rare_weights(d["lfit"], ds),
       eval_set=[(d["Xfit"][:60000], (d["lfit"][:60000] != "BENIGN").astype(int)), (d["Xtune"], ytune)], verbose=False)
ev = mx.evals_result()
out["convergence"] = dict(train_acc=(1 - np.array(ev["validation_0"]["error"])).tolist(),
                          val_acc=(1 - np.array(ev["validation_1"]["error"])).tolist(),
                          train_logloss=ev["validation_0"]["logloss"], val_logloss=ev["validation_1"]["logloss"])
print("convergence done", flush=True)

# ---- calibration of members (test set)
cal = {}
for i, k in enumerate(MODEL_ORDER):
    p = Se[:, i]; bins = np.linspace(0, 1, 11); b = np.clip(np.digitize(p, bins) - 1, 0, 9)
    conf = [float(p[b == j].mean()) if (b == j).any() else None for j in range(10)]
    acc = [float(yte[b == j].mean()) if (b == j).any() else None for j in range(10)]
    cnt = [int((b == j).sum()) for j in range(10)]
    ece = sum(c / len(p) * abs(a - f) for a, f, c in zip(acc, conf, cnt) if c > 0)
    cal[MODEL_NAME[k]] = dict(conf=conf, acc=acc, count=cnt, ece=float(ece), brier=float(brier_score_loss(yte, p)))
out["calibration"] = cal

# ---- member dependence (Spearman of conformal p-values)
rng = np.random.RandomState(3)
ben = np.where(yte == 0)[0]; atk = np.where(yte == 1)[0]
sb = rng.choice(ben, 20000, replace=False)
out["dependence"] = dict(benign_spearman=spearmanr(U[sb]).statistic.tolist(),
                         attack_spearman=spearmanr(U[rng.choice(atk, 20000, replace=False)]).statistic.tolist(),
                         benign_score_spearman=spearmanr(Se[sb]).statistic.tolist())

# ---- stratified sample for SHAP / embeddings (includes every FP and a set of FN)
cls = np.unique(lte)
per = 1500 if ds == "cic" else 700
samp = np.concatenate([rng.choice(np.where(lte == c)[0], min(per, int((lte == c).sum())), replace=False) for c in cls])
dec = np.where(E >= 1 / alpha, 2, np.where(E >= 1 / (10 * alpha), 1, 0))
fp_all = np.where((yte == 0) & (dec >= 1))[0]
fn_all = np.where((yte == 1) & (dec == 0))[0]
extra = np.concatenate([fp_all[:300], rng.choice(fn_all, min(300, len(fn_all)), replace=False)])
samp = np.unique(np.concatenate([samp, extra]))
import shap
expl = shap.TreeExplainer(models["xgb"])
sv = expl.shap_values(Xte[samp]); base = float(np.ravel(expl.expected_value)[0])
np.savez_compressed(os.path.join(ART, f"shap_{tag}.npz"), sv=sv, X=Xte[samp], lab=lte[samp], idx=samp,
                    E=E[samp], dec=dec[samp], base=base, feats=np.array(feats), s_xgb=Se[samp, 1])
print("shap done", flush=True)

# ---- embeddings (PCA fit on Fit block only; t-SNE on a 6k subsample)
pca = PCA(n_components=3, random_state=RS).fit(d["Xfit"][rng.choice(len(d["Xfit"]), 100000, replace=False)])
Z = pca.transform(Xte[samp])
ts_i = rng.choice(len(samp), min(6000, len(samp)), replace=False)
tsne = TSNE(n_components=2, perplexity=40, init="pca", random_state=RS).fit_transform(Xte[samp][ts_i])
np.savez_compressed(os.path.join(ART, f"embed_{tag}.npz"), Z=Z, evr=pca.explained_variance_ratio_,
                    lab=lte[samp], E=E[samp], dec=dec[samp], y=yte[samp], tsne=tsne, ts_i=ts_i,
                    loadings=pca.components_, feats=np.array(feats))
out["pca_evr"] = pca.explained_variance_ratio_.tolist()
out["counts"] = dict(fp_flagged=int(len(fp_all)), fp_dropped=int(((yte == 0) & (dec == 2)).sum()),
                     fn=int(len(fn_all)), fn_by_class={c: int(((lte == c) & (dec == 0)).sum()) for c in cls if c != "BENIGN"})
save_json(out, f"analysis_{tag}.json")
print("analysis done", out["counts"], flush=True)
