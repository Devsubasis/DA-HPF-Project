Place the CICIDS2017 and UNSW-NB15 CSV files here (see README.md).
