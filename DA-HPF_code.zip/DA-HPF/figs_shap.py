"""SHAP figures: beeswarm, global + class-wise importance, 2x2 waterfalls (TP / rare TP / FP / FN),
dependence plots. XGBoost member, TreeSHAP, test-set sample enriched with all flagged benign flows."""
import numpy as np, shap
from common import *
plt = style()

DS = {"cic": "CICIDS2017", "unsw": "UNSW-NB15"}
out = {}


def nice(c): return {"DDOS": "DDoS", "PORTSCAN": "PortScan", "DOS": "DoS", "BENIGN": "Benign"}.get(c, c.title())


for t in DS:
    z = np.load(os.path.join(ART, f"shap_{t}.npz"), allow_pickle=True)
    sv, X, lab, E, dec, base, feats = z["sv"], z["X"], z["lab"], z["E"], z["dec"], float(z["base"]), list(z["feats"])
    y = lab != "BENIGN"
    mabs = np.abs(sv).mean(0); order = np.argsort(mabs)[::-1]; share = mabs / mabs.sum() * 100
    top10 = []
    for r, i in enumerate(order[:10], 1):
        corr = np.corrcoef(X[:, i], sv[:, i])[0, 1]
        top10.append(dict(rank=r, feature=feats[i], mean_abs_shap=float(mabs[i]), share=float(share[i]),
                          direction="higher -> attack" if corr > 0 else "lower -> attack"))
    cls = [c for c in np.unique(lab)]
    out[t] = dict(top10=top10, top3_share=float(share[order[:3]].sum()), top10_share=float(share[order[:10]].sum()),
                  mean_sum_benign=float(sv[~y].sum(1).mean()), mean_sum_attack=float(sv[y].sum(1).mean()), base=base,
                  classwise={c: {feats[i]: float(np.abs(sv[lab == c, i]).mean()) for i in order[:10]} for c in cls})
    # ---- beeswarm
    plt.figure()
    shap.summary_plot(sv, X, feature_names=feats, show=False, max_display=15, plot_size=(5.2, 4.6))
    f = plt.gcf(); f.axes[0].set_title(f"{DS[t]}: SHAP summary (XGBoost member, log-odds)", fontsize=8.5)
    f.axes[0].tick_params(labelsize=7)
    savefig(f, f"P11_shap_beeswarm_{t}")
    # ---- global + class-wise importance
    fig, axs = plt.subplots(1, 2, figsize=(7.0, 3.0), gridspec_kw=dict(width_ratios=[1, 1.4]))
    k = order[:12][::-1]
    axs[0].barh(range(len(k)), mabs[k], color=C["blue"], height=0.7)
    for i_, kk in enumerate(k): axs[0].text(mabs[kk] * 1.02, i_, f"{share[kk]:.1f}%", va="center", fontsize=5.8)
    axs[0].set_yticks(range(len(k))); axs[0].set_yticklabels([feats[i] for i in k], fontsize=6.3)
    axs[0].set_xlabel(r"mean $|\phi_i|$ (log-odds)"); axs[0].set_title(f"(a) {DS[t]}: global importance", fontsize=8)
    show = cls if t == "cic" else ["BENIGN", "GENERIC", "EXPLOITS", "FUZZERS", "DOS", "WORMS"]
    k8 = order[:8]; w = 0.8 / len(show)
    pal = [CLS_COL.get(c, None) or c_ for c, c_ in zip(show, ["#9AA0A6", C["blue"], C["orange"], C["green"], C["pink"], C["verm"]])]
    for j, c in enumerate(show):
        vals = [np.abs(sv[lab == c, i]).mean() for i in k8]
        axs[1].bar(np.arange(8) + (j - len(show) / 2 + 0.5) * w, vals, w, color=pal[j], label=nice(c))
    axs[1].set_xticks(range(8)); axs[1].set_xticklabels([feats[i] for i in k8], rotation=35, ha="right", fontsize=5.8)
    axs[1].set_ylabel(r"mean $|\phi_i|$ per class"); axs[1].set_title(f"(b) {DS[t]}: class-wise attribution", fontsize=8)
    axs[1].legend(fontsize=5.6, ncol=2)
    fig.tight_layout(); savefig(fig, f"P12_shap_importance_global_classwise_{t}")
    # ---- 2x2 waterfalls
    if t == "cic":
        picks = [("true DROP: DDoS", (lab == "DDOS") & (dec == 2)), ("true DROP: Bot (rare class)", (lab == "BOT") & (dec == 2)),
                 ("false alarm: benign flagged", (~y) & (dec >= 1)), ("missed attack: Bot", (lab == "BOT") & (dec == 0))]
    else:
        picks = [("true DROP: Generic", (lab == "GENERIC") & (dec == 2)), ("true DROP: Worms (rare class)", (lab == "WORMS") & (dec == 2)),
                 ("false alarm: benign flagged", (~y) & (dec >= 1)), ("missed attack: Fuzzers", (lab == "FUZZERS") & (dec == 0))]
    fig, axs = plt.subplots(2, 2, figsize=(7.0, 5.0)); out[t]["waterfalls"] = {}
    for ax, (ttl, m) in zip(axs.ravel(), picks):
        ii = np.where(m)[0]
        if len(ii) == 0:
            ax.text(0.5, 0.5, "no such flow in sample", ha="center", transform=ax.transAxes); ax.axis("off"); continue
        fx = sv[ii].sum(1) + base
        i = ii[np.argsort(fx)[len(ii) // 2]]                      # median-margin representative
        c = sv[i]; o = np.argsort(np.abs(c))[::-1]; top = o[:9]; rest = c[o[9:]].sum()
        items = [(f"{feats[j]} = {X[i, j]:+.2f}", c[j]) for j in top] + [(f"{len(o)-9} other features", rest)]
        items = items[::-1]; cur = base
        for r_, (nm, v) in enumerate(items):
            ax.barh(r_, v, left=cur, color=C["verm"] if v > 0 else C["blue"], height=0.7)
            ax.text(max(cur, cur + v), r_, f" {v:+.2f}", va="center", ha="left", fontsize=5.6)
            cur += v
        ax.axvline(base, color="0.5", lw=0.6, ls=":"); ax.axvline(cur, color="k", lw=0.8)
        ax.set_yticks(range(len(items))); ax.set_yticklabels([x[0] for x in items], fontsize=5.6)
        ax.set_xlabel(r"model output (log-odds); $\phi_0$=" + f"{base:.2f}", fontsize=6.5)
        ax.set_title(f"{ttl}\n$f(x)$={cur:.2f}, CREF $E$={E[i]:.1f}, decision={['ALLOW','MONITOR','DROP'][dec[i]]}", fontsize=6.8)
        out[t]["waterfalls"][ttl] = dict(fx=float(cur), E=float(E[i]), decision=int(dec[i]),
                                         top=[(feats[j], float(X[i, j]), float(c[j])) for j in top[:5]])
    for ax in axs.ravel():
        lo_, hi_ = ax.get_xlim(); ax.set_xlim(lo_, hi_ + 0.12 * (hi_ - lo_))
    fig.tight_layout(); savefig(fig, f"P13_shap_waterfalls_{t}")
    # ---- dependence plots for top-3 features
    fig, axs = plt.subplots(1, 3, figsize=(7.0, 2.3))
    for ax, j in zip(axs, order[:3]):
        for c in (["BENIGN", "DDOS", "PORTSCAN", "BOT"] if t == "cic" else ["BENIGN", "GENERIC", "EXPLOITS", "FUZZERS", "WORMS"]):
            m = lab == c
            ax.scatter(X[m, j], sv[m, j], s=2, alpha=0.5, linewidths=0, label=nice(c), rasterized=True,
                       color=CLS_COL.get(c, {"GENERIC": C["blue"], "EXPLOITS": C["orange"], "FUZZERS": C["green"], "WORMS": C["verm"]}.get(c)))
        ax.axhline(0, color="k", lw=0.5); ax.set_xlabel(f"{feats[j]} (z-score)", fontsize=6.8); ax.set_ylabel(r"SHAP $\phi$", fontsize=7)
    axs[0].legend(fontsize=5.5, markerscale=3); fig.suptitle(f"{DS[t]}: SHAP dependence of the top-3 features", fontsize=8)
    fig.tight_layout(); savefig(fig, f"N18_shap_dependence_{t}")
save_json(out, "shap_summary.json")
print({t: [(r["feature"], round(r["share"], 1)) for r in out[t]["top10"]] for t in out})
