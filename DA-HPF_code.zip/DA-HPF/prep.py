"""Build leakage-free data variants.
Variants: cic (random stratified 70/30), cic_temporal (per-file row-order 70/30),
unsw (official partition). Within train: Fit 75% (UNSW 70%) / Val; Val -> TUNE/CAL/BAG0.
Feature selection (top-25 by RF importance) and Z-score use the Fit block only."""
import sys, numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from common import *


def select_features(Xfit, lab_fit, names, k=25):
    rng = np.random.RandomState(RS)
    idx = rng.choice(len(Xfit), min(len(Xfit), 150000), replace=False)
    y = (lab_fit[idx] != "BENIGN").astype(int)
    rf = RandomForestClassifier(n_estimators=60, max_samples=0.5, n_jobs=2,
                                class_weight="balanced_subsample", random_state=RS)
    rf.fit(logbot(Xfit[idx]), y)
    imp = rf.feature_importances_
    order = np.argsort(imp)[::-1]
    return [names[i] for i in order[:k]], {names[i]: float(imp[i]) for i in order}


def build(name, Xtr_df, ltr, Xte_df, lte, ds, fit_frac):
    names = list(Xtr_df.columns)
    Xtr, Xte = Xtr_df.values, Xte_df.values
    fi, vi = train_test_split(np.arange(len(Xtr)), test_size=1 - fit_frac,
                              stratify=ltr, random_state=RS)
    rng = np.random.RandomState(RS)
    t_i, c_i, b_i = partition_val(ltr[vi], rng)
    tune, cal, bag0 = vi[t_i], vi[c_i], vi[b_i]
    feats, imp = select_features(Xtr[fi], ltr[fi], names)
    cols = [names.index(f) for f in feats]
    Ltr, Lte = logbot(Xtr[:, cols]), logbot(Xte[:, cols])
    mu, sd = Ltr[fi].mean(0), Ltr[fi].std(0); sd[sd == 0] = 1.0
    Ztr, Zte = ((Ltr - mu) / sd).astype(np.float32), ((Lte - mu) / sd).astype(np.float32)
    np.savez_compressed(os.path.join(ART, f"{name}.npz"),
        Xfit=Ztr[fi], lfit=ltr[fi], Xtune=Ztr[tune], ltune=ltr[tune],
        Xcal=Ztr[cal], Xbag0=Ztr[bag0], Xte=Zte, lte=lte,
        feats=np.array(feats), mu=mu, sd=sd)
    info = dict(variant=name, n_train=len(Xtr), n_test=len(Xte), n_fit=len(fi),
                n_val=len(vi), n_tune=len(tune), n_cal=len(cal), n_bag0=len(bag0),
                n_tune_benign=int((ltr[tune] == "BENIGN").sum()),
                feats=feats, importance=imp,
                fit_counts={c: int((ltr[fi] == c).sum()) for c in np.unique(ltr)},
                tune_counts={c: int((ltr[tune] == c).sum()) for c in np.unique(ltr)},
                test_counts={c: int((lte == c).sum()) for c in np.unique(lte)})
    save_json(info, f"prep_{name}.json")
    print(f"[{name}] fit={len(fi):,} tune={len(tune):,} cal={len(cal):,} "
          f"bag0={len(bag0):,} test={len(Xte):,} | top5={feats[:5]}")


if __name__ == "__main__":
    which = sys.argv[1:] or ["cic", "cic_temporal", "unsw"]
    if any(w.startswith("cic") for w in which):
        t0 = time.time()
        X, lab, fid, row, meta = load_cic_raw()
        save_json(dict(meta, counts={c: int((lab == c).sum()) for c in np.unique(lab)}),
                  "cic_raw_meta.json")
        print(f"[cic] raw={meta['n_raw']:,} clean={meta['n_clean']:,} "
              f"{dict(zip(*np.unique(lab, return_counts=True)))} {time.time()-t0:.0f}s")
        if "cic" in which:
            tr, te = train_test_split(np.arange(len(X)), test_size=0.30,
                                      stratify=lab, random_state=RS)
            build("cic", X.iloc[tr], lab[tr], X.iloc[te], lab[te], "cic", 0.75)
        if "cic_temporal" in which:
            # chronological proxy: CICFlowMeter writes flows in completion order;
            # first 70% of rows of each capture file -> train, last 30% -> test
            tr, te = [], []
            for f in np.unique(fid):
                ii = np.where(fid == f)[0]; ii = ii[np.argsort(row[ii])]
                cut = int(0.70 * len(ii)); tr.append(ii[:cut]); te.append(ii[cut:])
            tr, te = np.concatenate(tr), np.concatenate(te)
            build("cic_temporal", X.iloc[tr], lab[tr], X.iloc[te], lab[te], "cic", 0.75)
    if "unsw" in which:
        Xtr, ltr, Xte, lte = load_unsw_raw()
        build("unsw", Xtr, ltr, Xte, lte, "unsw", 0.70)
