"""Extra theory figures: rank budget r(alpha), calibration-conditional mean mu(B) (Dirichlet spacings),
comonotone inflation of independence-based p-value combination."""
import numpy as np
from scipy.stats import chi2, norm
from common import *
plt = style()

DS = {"cic": "CICIDS2017", "unsw": "UNSW-NB15"}
core = {t: load_json(f"core_{t}.json") for t in DS}
out = {}

# ---------------------------------------------------------------- rank budget + mu(B)
fig, axs = plt.subplots(1, 2, figsize=(7.0, 2.6))
al = np.logspace(-4, -1, 400)
for t, ls in [("cic", "-"), ("unsw", "--")]:
    nb, k = core[t]["n_b"], core[t]["kappa"]
    r = np.floor((nb + 1) * (k * al) ** (1 / (1 - k))) - 1
    r = np.where(r < 0, np.nan, r)
    axs[0].step(al, r, where="post", ls=ls, color="k", lw=1.1, label=f"{DS[t]} ($n_b$={nb:,}, $\\kappa$={k})")
for nb in [10000, 100000, 1000000]:
    k = kappa_opt(nb); r = np.floor((nb + 1) * (k * al) ** (1 / (1 - k))) - 1
    axs[0].plot(al, np.where(r < 0, np.nan, r), color=C["blue"], lw=0.7, alpha=0.6)
    axs[0].text(al[-1] * 1.05, r[-1], f"$n_b$=$10^{int(np.log10(nb))}$", fontsize=6, color=C["blue"], va="center")
axs[0].set_xscale("log"); axs[0].set_yscale("symlog", linthresh=1); axs[0].set_xlim(1e-4, 0.25); axs[0].set_ylim(-0.4, 2e4)
axs[0].set_xlabel(r"level $\alpha$"); axs[0].set_ylabel(r"rank budget $r(\alpha)$")
axs[0].set_title(r"(a) $r(\alpha)=\lfloor(n_b+1)(\kappa\alpha)^{1/(1-\kappa)}\rfloor-1$", fontsize=8)
axs[0].legend(fontsize=6, loc="upper left"); axs[0].grid(True)
rng = np.random.RandomState(0); res = {}
for t, col in [("cic", C["verm"]), ("unsw", C["blue"])]:
    nb, k = core[t]["n_b"], core[t]["kappa"]; N = nb + 1
    c = k * (np.arange(1, N + 1) / N) ** (k - 1)
    mus = np.array([c @ (lambda e: e / e.sum())(rng.exponential(size=N)) for _ in range(3000)])
    axs[1].hist(mus, bins=60, histtype="stepfilled", alpha=0.45, color=col, density=True,
                label=f"{DS[t]}: mean {mus.mean():.3f}, sd {mus.std():.3f}")
    res[t] = dict(mean_exact=float(c.mean()), sd_exact=float(np.sqrt((np.mean(c ** 2) - c.mean() ** 2) / (N + 1))),
                  mc_mean=float(mus.mean()), mc_sd=float(mus.std()), mc_p_above_1=float((mus > 1).mean()),
                  approx=float(1 - N ** (-k)))
axs[1].axvline(1, color="k", lw=0.9, ls=":"); axs[1].set_xlabel(r"calibration-conditional mean $\mu(\mathcal{B})=\mathbb{E}[E\,|\,\mathcal{B}]$")
axs[1].set_ylabel("density"); axs[1].set_title(r"(b) $\mu(\mathcal{B})=\sum_j c_j D_j$, $D\sim\mathrm{Dirichlet}(1,\ldots,1)$", fontsize=8)
axs[1].legend(fontsize=6)
fig.tight_layout(); savefig(fig, "N30_rank_budget_and_conditional_mean")
out["mu_B"] = res

# ---------------------------------------------------------------- comonotone inflation
fig, ax = plt.subplots(figsize=(3.6, 2.7))
a = np.logspace(-4, -1, 200); K = 4
ax.loglog(a, np.exp(-chi2.isf(a, 2 * K) / (2 * K)) / a, color=C["pink"], lw=1.4, label="Fisher, comonotone members")
ax.loglog(a, norm.sf(norm.isf(a) / np.sqrt(K)) / a, color=C["orange"], lw=1.4, ls="--", label="Stouffer, comonotone members")
ax.axhline(1, color="k", lw=0.9, label=r"valid level (e-mean, any dependence)")
for t, mk in [("cic", "o"), ("unsw", "s")]:
    for nm, col in [("Fisher (indep.)", C["pink"]), ("Stouffer (indep.)", C["orange"])]:
        g = core[t]["guarantee"][nm]; aa = np.array(g["alpha"]); ff = np.array(g["far"])
        sel = (aa >= 1e-4) & (aa <= 0.1)
        ax.plot(aa[sel][::4], (ff[sel] / aa[sel])[::4], mk, color=col, ms=3.5, mfc="white", mew=1)
ax.plot([], [], "o", color="0.3", mfc="white", label="measured, CICIDS2017"); ax.plot([], [], "s", color="0.3", mfc="white", label="measured, UNSW-NB15")
ax.set_xlabel(r"nominal level $\alpha$"); ax.set_ylabel(r"false-alarm inflation FAR$/\alpha$")
ax.legend(fontsize=5.6, loc="upper right"); ax.grid(True, which="major")
fig.tight_layout(); savefig(fig, "N31_comonotone_inflation_fisher_stouffer")
out["comonotone"] = {str(x): dict(fisher=float(np.exp(-chi2.isf(x, 8) / 8) / x), stouffer=float(norm.sf(norm.isf(x) / 2) / x))
                     for x in [1e-2, 1e-3, 1e-4]}
save_json(out, "theory_extra.json"); print(out)
