"""Emit markdown tables with the exact measured numbers for the report."""
import numpy as np
from common import *

L = []
P = lambda s="": L.append(s)
DS = {"cic": "CICIDS2017", "unsw": "UNSW-NB15"}
ALPHA = {"cic": "0.001", "unsw": "0.01"}
core = {t: load_json(f"core_{t}.json") for t in DS}
prep = {t: load_json(f"prep_{t}.json") for t in DS}

P("### T-A. Protocol, calibration size and attainability")
P("| Dataset | Fit | TUNE | CAL ($n_b$) | BAG0 | Test | $\\kappa^*$ | $\\lambda^*$ (RF, XGB, LGBM, Cat) | $E_{\\max}$ | $\\alpha_{\\min}$ | $\\kappa^\\circ=1/\\ln(n_b+1)$ |")
P("|---|---|---|---|---|---|---|---|---|---|---|")
for t in DS:
    p, c = prep[t], core[t]
    P(f"| {DS[t]} | {p['n_fit']:,} | {p['n_tune']:,} | {p['n_cal']:,} | {p['n_bag0']:,} | {p['n_test']:,} | {c['kappa']} | "
      f"({', '.join(f'{x:.3f}' for x in c['lam'])}) | {c['E_max']:.1f} | {c['alpha_min']:.2e} | {c['kappa_opt']:.4f} |")
P()
order = ["RF", "AdaBoost", "XGBoost", "LightGBM", "CatBoost", "XGBoost (no cost)", "Soft voting", "Weighted voting",
         "Hard voting (>=2/4)", "Stacking (LR)", "CREF w/o p-calibration", "Fisher (indep.)", "Stouffer (indep.)",
         "Bonferroni (K min u)", "p-averaging (2 mean u)", "CREF w/o e-values (2 sum lam u)",
         "Conformal single (XGBoost)", "Uniform e-mean", "CREF (proposed)"]
for t in DS:
    a = ALPHA[t]; r = core[t]["at_alpha"][a]; tf = core[t]["threshold_free"]
    ada = np.load(os.path.join(ART, f"ada_{t}.npz")); ev = np.load(os.path.join(ART, f"evid_{t}.npz"), allow_pickle=True)
    from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score, matthews_corrcoef,
                                 roc_auc_score, average_precision_score, balanced_accuracy_score)
    y = ev["yte"]; thr = np.quantile(ada["cal"], 1 - float(a), method="higher"); yh = (ada["te"] > thr).astype(int)
    r = dict(r); r["AdaBoost"] = dict(acc=accuracy_score(y, yh), prec=precision_score(y, yh), rec=recall_score(y, yh),
                                     f1=f1_score(y, yh), macro_f1=f1_score(y, yh, average="macro"), mcc=matthews_corrcoef(y, yh),
                                     bal_acc=balanced_accuracy_score(y, yh), far=float(yh[y == 0].mean()), fnr=float(1 - yh[y == 1].mean()),
                                     guarantee="none (empirical CAL quantile)")
    tf = dict(tf); tf["AdaBoost"] = dict(roc_auc=roc_auc_score(y, ada["te"]), pr_auc=average_precision_score(y, ada["te"]))
    P(f"### T-B ({DS[t]}). All methods at $\\alpha$ = {a} (thresholds from non-test data only)")
    P("| Method | Acc | Prec | Rec (TPR) | F1 | Macro-F1 | MCC | Bal. acc | FAR | FNR | ROC-AUC | PR-AUC | FAR/$\\alpha$ | Guarantee |")
    P("|---|---|---|---|---|---|---|---|---|---|---|---|---|---|")
    for m in order:
        if m not in r: continue
        x = r[m]; z = tf.get(m, {})
        P(f"| {m} | {x['acc']*100:.3f} | {x['prec']*100:.3f} | {x['rec']*100:.3f} | {x['f1']*100:.3f} | {x['macro_f1']*100:.3f} | "
          f"{x['mcc']*100:.3f} | {x['bal_acc']*100:.3f} | {x['far']*100:.4f}% | {x['fnr']*100:.3f}% | "
          f"{z.get('roc_auc', float('nan')):.5f} | {z.get('pr_auc', float('nan')):.5f} | {x['far']/float(a):.3f} | {x.get('guarantee','')} |")
    P()
    pc = core[t]["at_alpha"][a]
    cls = list(pc["CREF (proposed)"]["per_class"])
    P(f"Per-class recall (%) at $\\alpha$ = {a}:")
    P("| Method | " + " | ".join(cls) + " |"); P("|---|" + "---|" * len(cls))
    for m in ["XGBoost", "Soft voting", "Stacking (LR)", "Uniform e-mean", "CREF (proposed)"]:
        P(f"| {m} | " + " | ".join(f"{pc[m]['per_class'][c]*100:.2f}" for c in cls) + " |")
    P()
mf = load_json("matched_far.json")
P("### T-C. Oracle matched-FAR analysis (test-tuned thresholds, analysis only)")
P("| Dataset | target FAR (= CREF at $\\alpha$) | XGBoost | LightGBM | CatBoost | Soft voting | Stacking | Uniform e-mean | CREF |")
P("|---|---|---|---|---|---|---|---|---|")
for t in DS:
    m = mf[t]["matched"]
    P(f"| {DS[t]} | {mf[t]['target_far']*100:.4f}% | " + " | ".join(f"{m[k]['tpr']*100:.3f}" for k in
      ["XGBoost", "LightGBM", "CatBoost", "Soft voting", "Stacking (LR)", "Uniform e-mean", "CREF (proposed)"]) + " |")
P()
P("### T-D. Guarantee validity at attainable levels (CREF, test benign)")
for t in DS:
    g = core[t]["guarantee"]["CREF (proposed)"]
    P(f"{DS[t]} ($n_b$={core[t]['n_b']:,}, $E_{{\\max}}$={core[t]['E_max']:.1f}):")
    P("| $\\alpha$ | $1/\\alpha$ | attainable | benign FAR | TPR | FAR $\\leq\\alpha$ |"); P("|---|---|---|---|---|---|")
    for a_, f_, tp_, at_ in zip(g["alpha"], g["far"], g["tpr"], g["attainable"]):
        if a_ < 5e-5: continue
        P(f"| {a_:.2e} | {1/a_:.0f} | {'yes' if at_ else 'no'} | {f_*100:.4f}% | {tp_*100:.2f}% | {'yes' if f_ <= a_ else 'NO'} |")
    viol = sum(1 for a_, f_, at_ in zip(g["alpha"], g["far"], g["attainable"]) if at_ and f_ > a_)
    P(f"Violations at attainable levels: **{viol}** of {sum(g['attainable'])}."); P()
P("### T-E. Miscalibration invariance (CatBoost scores replaced by $p^\\gamma$)")
P("| Dataset | $\\gamma$ | CREF scores identical | max abs $\\Delta E$ | soft-voting FAR at fixed threshold | soft-voting TPR |")
P("|---|---|---|---|---|---|")
for t in DS:
    for g, v in core[t]["miscalibration"]["results"].items():
        P(f"| {DS[t]} | {g} | {v['cref_identical']} | {v.get('cref_max_abs_diff', 0):.1e} | {v['vote_far']*100:.4f}% | {v['vote_tpr']*100:.3f}% |")
P()
P("### T-F. Leakage audit (CICIDS2017, $\\alpha$ = 0.001)")
P("| Split | Method | Macro-F1 | MCC | TPR | FAR | ROC-AUC |"); P("|---|---|---|---|---|---|---|")
for tag, nm in [("cic", "random 70/30"), ("cic_temporal", "temporal (row-order) 70/30"), ("cic_nodport", "random, Destination Port removed")]:
    c = load_json(f"core_{tag}.json")
    for m in ["XGBoost", "Soft voting", "Fisher (indep.)", "CREF (proposed)"]:
        x = c["at_alpha"]["0.001"][m]; z = c["threshold_free"].get(m, {})
        P(f"| {nm} | {m} | {x['macro_f1']*100:.3f} | {x['mcc']*100:.3f} | {x['rec']*100:.3f} | {x['far']*100:.4f}% | {z.get('roc_auc', float('nan')):.5f} |")
P()
lc = load_json("label_conflict_cic.json")
P("### T-G. Error analysis: missed attacks that are exact duplicates of benign-labelled flows (CICIDS2017, CREF $\\alpha$=0.001)")
P("Missed = decision ALLOW (not flagged even at the MONITOR level $1/(10\\alpha)$).")
P("| Class | test flows | missed | missed & exact benign duplicate |"); P("|---|---|---|---|")
for c in ["DDOS", "PORTSCAN", "BOT"]:
    x = lc[c]; P(f"| {c} | {x['n']:,} | {x['missed']} | {x['missed_and_dup']} ({x['missed_and_dup']/max(x['missed'],1)*100:.1f}%) |")
P(f"| benign flagged (MONITOR/DROP) | - | {lc['BENIGN_flagged']['n']} | duplicates of attacks: {lc['BENIGN_flagged']['dup_of_attack']} |"); P()
un = load_json("unseen_summary.json")
P("### T-H. Unseen attack-class evaluation (class removed from Fit and TUNE)")
P("| Dataset | held-out class | CREF unseen (seen) | XGBoost unseen (seen) | Soft voting unseen (seen) | FAR CREF / XGB / SV |")
P("|---|---|---|---|---|---|")
for x in un:
    P(f"| {DS[x['ds']]} | {x['cls']} | {x['unseen']['CREF (proposed)']*100:.2f} ({x['seen']['CREF (proposed)']*100:.2f}) | "
      f"{x['unseen']['XGBoost']*100:.2f} ({x['seen']['XGBoost']*100:.2f}) | {x['unseen']['Soft voting']*100:.2f} ({x['seen']['Soft voting']*100:.2f}) | "
      f"{x['far']['CREF (proposed)']*100:.4f}% / {x['far']['XGBoost']*100:.4f}% / {x['far']['Soft voting']*100:.4f}% |")
P()
for t in DS:
    a = load_json(f"act_{t}.json")
    P(f"### T-I ({DS[t]}). ACT regime-detector validity (benign-only streams)")
    P("| $\\alpha_{reg}$ | bound $1/\\alpha_{reg}$ | reps | censored | mean run length (lower bound) | median | Ville $P(\\sup K\\geq10)$ | $P(\\sup K\\geq20)$ | $P(\\sup K\\geq100)$ |")
    P("|---|---|---|---|---|---|---|---|---|")
    for k, v in a["regime_validity"].items():
        P(f"| {k} | {v['bound']:.0f} | {v['reps']} | {v['censored']} | {v['mean_rl_lower']:,.0f} | {v['median_rl']:,.0f} | "
          f"{v['ville']['0.1']:.3f} | {v['ville']['0.05']:.3f} | {v['ville']['0.01']:.3f} |")
    P(); p = a["params"]
    P(f"ACT parameters: $\\kappa_s$={p['ks']}, $\\alpha_{{reg}}$={p['alpha_reg']:g}, $D$={p['D']}, $q$={p['q']}, $\\bar\\alpha$={p['abar']:g}, "
      f"$L_{{\\max}}=L_0$={p['L_max']}, $\\rho$={p['rho']}, $\\alpha_{{calm}}$={p['a_calm']:.2e}, $\\alpha_{{alert}}$={p['a_alert']:g}; "
      f"$\\alpha_{{\\min}}$={a['alpha_min']:.2e}; $|B_0|$={a['n_bag0']:,}.")
    P(); P(f"### T-J ({DS[t]}). Six traffic regimes, 20 streams each (mean $\\pm$ SD)")
    P("| Regime | Method | benign drops | benign flagged | attack drop % | attack flag % | delay (flows) | recovery (flows) | mode switches | regime false alarms |")
    P("|---|---|---|---|---|---|---|---|---|---|")
    for rg, mm in a["regimes"].items():
        for m, v in mm.items():
            f = lambda k, s=1, d=2: (f"{v[k]['mean']*s:.{d}f} ± {v[k]['sd']*s:.{d}f}" if k in v and v[k]['mean'] is not None else "-")
            P(f"| {rg} | {m} | {f('benign_drop')} | {f('benign_flag')} | {f('drop_rate_attack',100)} | {f('flag_rate_attack',100)} | "
              f"{f('detection_delay',1,1)} | {f('recovery_time',1,0)} | {f('mode_switches',1,2)} | {f('regime_false_alarms',1,2)} |")
    P()
for t in DS:
    r = load_json(f"robust_{t}.json")
    P(f"### T-K ({DS[t]}). Robustness ($\\alpha$={r['alpha']:g})")
    P("| Perturbation | level | CREF Macro-F1 / FAR | XGBoost Macro-F1 / FAR | Soft voting Macro-F1 / FAR |"); P("|---|---|---|---|---|")
    for sec in ["noise", "missing"]:
        for lv, v in r[sec].items():
            P(f"| {sec} | {lv} | " + " | ".join(f"{v[m]['macro_f1']*100:.2f} / {v[m]['far']*100:.4f}%" for m in ["CREF (proposed)", "XGBoost", "Soft voting"]) + " |")
    P("| Prevalence | attack share | CREF precision | XGBoost precision | Soft voting precision |"); P("|---|---|---|---|---|")
    for lv, v in r["prevalence"].items():
        P(f"| prevalence | {lv} | " + " | ".join(f"{v[m]['precision']*100:.3f}" for m in ["CREF (proposed)", "XGBoost", "Soft voting"]) + " |")
    P()
tm = load_json("timing_cic.json")
P("### T-L. Computational cost (CICIDS2017 models)")
h = tm["hardware"]
P(f"Hardware: {h['cpu']}, {h['logical_cores']} logical cores, {h['ram_gb']} GB RAM, {h['os']}, Python {h['python']}, GPU: {h['gpu']}.")
P("| Pipeline (online, 1 thread) | P50 ms | P95 ms | P99 ms | mean ms | flows/s | RSS MB |"); P("|---|---|---|---|---|---|---|")
for k, v in tm["online"].items():
    P(f"| {k} | {v['p50']:.3f} | {v['p95']:.3f} | {v['p99']:.3f} | {v['mean']:.3f} | {v['flows_per_s_online']:.0f} | {v['rss_mb']:.0f} |")
b = tm["batch"]
P(f"Batch (100,000 flows, 2 threads): XGBoost {b['xgb_flows_per_s']:,.0f} flows/s; 4 members {b['members_flows_per_s']:,.0f}; "
  f"CREF fusion layer alone {b['fusion_only_flows_per_s']:,.0f}; ACT regime layer alone {b['act_regime_layer_flows_per_s']:,.0f}; "
  f"CREF total {b['cref_total_flows_per_s']:,.0f}; CREF+ACT total {b['cref_act_total_flows_per_s']:,.0f}. Models on disk {b['model_disk_mb']['all4']:.1f} MB; references {b['refs_mb']:.2f} MB.")
P()
sh = load_json("shap_summary.json")
for t in DS:
    P(f"### T-M ({DS[t]}). Top-10 SHAP features (XGBoost member)")
    P("| Rank | Feature | mean abs SHAP | share % | direction |"); P("|---|---|---|---|---|")
    for x in sh[t]["top10"]:
        P(f"| {x['rank']} | {x['feature']} | {x['mean_abs_shap']:.3f} | {x['share']:.1f} | {x['direction']} |")
    P(f"Top-3 share {sh[t]['top3_share']:.1f}%, top-10 share {sh[t]['top10_share']:.1f}%; mean SHAP sum benign {sh[t]['mean_sum_benign']:.2f}, "
      f"attack {sh[t]['mean_sum_attack']:.2f}, base value {sh[t]['base']:.3f}."); P()
an = {t: load_json(f"analysis_{t}.json") for t in DS}
P("### T-N. Member calibration (test set)")
P("| Dataset | " + " | ".join(MODEL_NAME[k] + " ECE / Brier" for k in MODEL_ORDER) + " |"); P("|---|---|---|---|---|")
for t in DS:
    P(f"| {DS[t]} | " + " | ".join(f"{an[t]['calibration'][MODEL_NAME[k]]['ece']:.4f} / {an[t]['calibration'][MODEL_NAME[k]]['brier']:.4f}" for k in MODEL_ORDER) + " |")
P()
if os.path.exists(os.path.join(RES, "stats.json")):
    st = load_json("stats.json")
    for t in [x for x in DS if x in st]:
        o = st[t]
        P(f"### T-O ({DS[t]}). 10-fold CV (values in %), Friedman, exact Wilcoxon (CREF vs each), Holm")
        for met in ["mcc", "macro_f1", "tpr", "far", "min_class_recall"]:
            m = o["metrics"][met]
            P(f"**{met}** — Friedman $\\chi^2$={m['friedman_chi2']:.2f}, p={m['friedman_p']:.2e}, Kendall W={m['kendall_W']:.3f}, Nemenyi CD={m['nemenyi_cd']:.2f}")
            P("| Method | mean ± SD | 95% CI | avg rank | CREF − method | Wilcoxon W | p | p (Holm) | rank-biserial | Cohen $d_z$ |")
            P("|---|---|---|---|---|---|---|---|---|---|")
            pw = {r_["vs"]: r_ for r_ in m["pairwise_cref"]}
            sc = 100 if met != "far" else 100
            for meth in o["methods"]:
                d_ = m["desc"][meth]; q = pw.get(meth)
                P(f"| {meth} | {d_['mean']*sc:.4f} ± {d_['sd']*sc:.4f} | [{d_['ci'][0]*sc:.4f}, {d_['ci'][1]*sc:.4f}] | {m['avg_rank'][meth]:.2f} | "
                  + (f"{q['mean_diff']*sc:+.4f} | {q['W']:.1f} | {q['p']:.4f} | {q['p_holm']:.4f} | {q['rank_biserial']:+.2f} | {q['cohen_dz']:+.2f} |" if q else "- | - | - | - | - | - |"))
            P()
open(os.path.join(RES, "TABLES.md"), "w").write("\n".join(L))
print("\n".join(L)[:3000])
