"""Core evaluation for one trained tag.
usage: python eval_core.py TAG VARIANT"""
import sys, numpy as np
from scipy.stats import chi2, norm
from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score,
                             matthews_corrcoef, roc_auc_score, average_precision_score,
                             balanced_accuracy_score)
from sklearn.linear_model import LogisticRegression
from common import *


def metrics(yhat, y, lab, scores=None):
    tn = int(((yhat == 0) & (y == 0)).sum()); fp = int(((yhat == 1) & (y == 0)).sum())
    fn = int(((yhat == 0) & (y == 1)).sum()); tp = int(((yhat == 1) & (y == 1)).sum())
    out = dict(acc=accuracy_score(y, yhat), prec=precision_score(y, yhat, zero_division=0),
               rec=recall_score(y, yhat), f1=f1_score(y, yhat),
               macro_f1=f1_score(y, yhat, average="macro"),
               mcc=matthews_corrcoef(y, yhat), bal_acc=balanced_accuracy_score(y, yhat),
               far=fp / max(fp + tn, 1), fnr=fn / max(fn + tp, 1),
               tp=tp, fp=fp, tn=tn, fn=fn,
               per_class={c: float(yhat[lab == c].mean()) for c in np.unique(lab) if c != "BENIGN"})
    if scores is not None:
        out["roc_auc"] = roc_auc_score(y, scores); out["pr_auc"] = average_precision_score(y, scores)
    return out


def run(tag, variant, exclude=None):
    d = np.load(os.path.join(ART, f"{variant}.npz"), allow_pickle=True)
    s = np.load(os.path.join(ART, f"scores_{tag}.npz"), allow_pickle=True)
    ds = "unsw" if variant.startswith("unsw") else "cic"
    lt, lte = d["ltune"], d["lte"]
    St, Sc, Sb, Se = s["S_tune"], s["S_cal"], s["S_bag0"], s["S_te"]
    if exclude:
        keep = lt != exclude; St, lt = St[keep], lt[keep]
    yte = (lte != "BENIGN").astype(int)
    classes = [c for c in np.unique(lt) if c != "BENIGN"]
    t0 = time.time()
    sel = select_kappa_lambda(St, lt, classes)
    kap, lam = sel["kappa"], np.array(sel["lam"])
    refs = build_refs(Sc)                               # CAL: frozen references
    n_b = len(Sc)
    U = conformal_u(refs, Se)
    E = e_vals(U, kap) @ lam
    E_uni = e_vals(U, kap).mean(1)
    Emax = e_max(kap, n_b)
    print(f"[{tag}] kappa*={kap} lambda*={np.round(lam,3).tolist()} n_b={n_b} "
          f"E_max={Emax:.1f} alpha_min={1/Emax:.2e} ({time.time()-t0:.0f}s)", flush=True)

    # ---------------- fusion baselines
    K = 4
    mcc_t = np.array([matthews_corrcoef((lt != "BENIGN"), St[:, k] >= 0.5) for k in range(K)])
    w = np.exp((mcc_t - mcc_t.max()) / 0.05); w /= w.sum()
    stack = LogisticRegression(max_iter=2000).fit(np.log(np.clip(St, 1e-7, 1)) - np.log(np.clip(1 - St, 1e-7, 1)),
                                                  (lt != "BENIGN").astype(int))
    def logit(S): return np.log(np.clip(S, 1e-7, 1)) - np.log(np.clip(1 - S, 1e-7, 1))
    score_te = {MODEL_NAME[k]: Se[:, i] for i, k in enumerate(MODEL_ORDER)}
    score_cal = {MODEL_NAME[k]: Sc[:, i] for i, k in enumerate(MODEL_ORDER)}
    score_te["Soft voting"], score_cal["Soft voting"] = Se.mean(1), Sc.mean(1)
    score_te["Weighted voting"], score_cal["Weighted voting"] = Se @ w, Sc @ w
    score_te["Stacking (LR)"] = stack.predict_proba(logit(Se))[:, 1]
    score_cal["Stacking (LR)"] = stack.predict_proba(logit(Sc))[:, 1]
    score_te["CREF w/o p-calibration"], score_cal["CREF w/o p-calibration"] = Se @ lam, Sc @ lam
    if "W1_te" in s.files:
        score_te["XGBoost (no cost)"], score_cal["XGBoost (no cost)"] = s["W1_te"], s["W1_cal"]

    # conformal-statistics (p-value fusion) family, thresholds set by alpha (no test tuning)
    Uc = np.clip(U, 1e-12, 1)
    P = {"Bonferroni (K min u)": np.minimum(1, K * U.min(1)),
         "Fisher (indep.)": chi2.sf(-2 * np.log(Uc).sum(1), 2 * K),
         "Stouffer (indep.)": norm.sf(norm.isf(Uc).sum(1) / np.sqrt(K)),
         "p-averaging (2 mean u)": np.minimum(1, 2 * U.mean(1)),
         "CREF w/o e-values (2 sum lam u)": np.minimum(1, 2 * U @ lam)}
    xgb_i = MODEL_ORDER.index("xgb")
    EV = {"Conformal single (XGBoost)": e_vals(U[:, xgb_i], kap),
          "Uniform e-mean": E_uni, "CREF (proposed)": E}

    alphas = [1e-2, 5e-3, 2e-3, 1e-3]
    res = dict(tag=tag, variant=variant, kappa=kap, lam=lam.tolist(), n_b=n_b, E_max=Emax,
               alpha_min=1 / Emax, kappa_opt=kappa_opt(n_b), E_max_opt=e_max(kappa_opt(n_b), n_b),
               selection=sel, vote_w=w.tolist(), member_tune_mcc=mcc_t.tolist(),
               at_alpha={}, threshold_free={}, guarantee={}, n_test=len(yte))
    for nm, sc in score_te.items():
        res["threshold_free"][nm] = dict(roc_auc=roc_auc_score(yte, sc), pr_auc=average_precision_score(yte, sc))
    for nm, e in EV.items():
        res["threshold_free"][nm] = dict(roc_auc=roc_auc_score(yte, e), pr_auc=average_precision_score(yte, e))
    for nm, p in P.items():
        res["threshold_free"][nm] = dict(roc_auc=roc_auc_score(yte, -p), pr_auc=average_precision_score(yte, -p))
    for a in alphas:
        r = {}
        for nm, sc in score_te.items():   # empirical calibration on CAL benign (no finite-sample guarantee)
            thr = np.quantile(score_cal[nm], 1 - a, method="higher")
            r[nm] = metrics((sc > thr).astype(int), yte, lte)
            r[nm]["guarantee"] = "none (empirical CAL quantile)"
        # hard voting: majority of CAL-calibrated members
        votes = np.stack([(Se[:, k] > np.quantile(Sc[:, k], 1 - a, method="higher")) for k in range(K)], 1)
        r["Hard voting (>=2/4)"] = metrics((votes.sum(1) >= 2).astype(int), yte, lte)
        r["Hard voting (>=2/4)"]["guarantee"] = "none"
        for nm, p in P.items():
            r[nm] = metrics((p <= a).astype(int), yte, lte)
            r[nm]["guarantee"] = "invalid (needs independence)" if "indep" in nm else "valid, any dependence"
        for nm, e in EV.items():
            r[nm] = metrics((e >= 1 / a).astype(int), yte, lte)
            r[nm]["guarantee"] = "valid (Markov on e-value)"
            r[nm]["attainable"] = bool(1 / a <= (e_max(kap, n_b) if True else 0))
        res["at_alpha"][str(a)] = r
    # ---------------- guarantee curves (fixed-alpha mode)
    ag = np.logspace(-4, -0.5, 36)
    ben = yte == 0
    for nm, e in EV.items():
        res["guarantee"][nm] = dict(alpha=ag.tolist(),
            far=[float((e[ben] >= 1 / x).mean()) for x in ag],
            tpr=[float((e[~ben] >= 1 / x).mean()) for x in ag],
            attainable=[bool(1 / x <= Emax) for x in ag])
    for nm, p in P.items():
        res["guarantee"][nm] = dict(alpha=ag.tolist(),
            far=[float((p[ben] <= x).mean()) for x in ag],
            tpr=[float((p[~ben] <= x).mean()) for x in ag])
    # ---------------- miscalibration invariance (CatBoost distorted by g(p)=p^gamma)
    ci = MODEL_ORDER.index("cat"); a0 = 1e-3 if ds == "cic" else 1e-2
    thr_v = np.quantile(Sc.mean(1), 1 - a0, method="higher")
    inv = {}
    for g in [0.25, 0.5, 2.0, 3.0]:
        Sc2, Se2 = Sc.copy(), Se.copy(); Sc2[:, ci] **= g; Se2[:, ci] **= g
        E2 = e_vals(conformal_u(build_refs(Sc2), Se2), kap) @ lam
        v2 = Se2.mean(1) > thr_v
        inv[str(g)] = dict(cref_identical=bool(np.array_equal(E2, E)),
                           cref_max_abs_diff=float(np.abs(E2 - E).max()),
                           vote_far=float(v2[ben].mean()), vote_tpr=float(v2[~ben].mean()),
                           vote_per_class={c: float(v2[lte == c].mean()) for c in classes})
    v0 = Se.mean(1) > thr_v
    inv["1.0"] = dict(cref_identical=True, vote_far=float(v0[ben].mean()), vote_tpr=float(v0[~ben].mean()),
                      vote_per_class={c: float(v0[lte == c].mean()) for c in classes})
    res["miscalibration"] = dict(alpha=a0, results=inv)
    save_json(res, f"core_{tag}.json")
    np.savez_compressed(os.path.join(ART, f"evid_{tag}.npz"), E=E, E_uni=E_uni, U=U, yte=yte, lte=lte,
                        P_fisher=P["Fisher (indep.)"], P_stouffer=P["Stouffer (indep.)"],
                        P_bonf=P["Bonferroni (K min u)"], soft=Se.mean(1), stack=score_te["Stacking (LR)"])
    return res


if __name__ == "__main__":
    tag, variant = sys.argv[1], sys.argv[2]
    exclude = sys.argv[3] if len(sys.argv) > 3 else None
    r = run(tag, variant, exclude)
    a = "0.001" if variant.startswith("cic") else "0.01"
    print(f"\n{'method':34s} {'acc':>7} {'mF1':>7} {'MCC':>7} {'FAR%':>8} {'TPR':>7}")
    for nm, m in r["at_alpha"][a].items():
        print(f"{nm:34s} {m['acc']*100:7.3f} {m['macro_f1']*100:7.3f} {m['mcc']*100:7.3f} "
              f"{m['far']*100:8.4f} {m['rec']*100:7.3f}")
