"""Error analysis: missed attacks / flagged benign flows that are exact feature duplicates
of opposite-label training flows (CICIDS2017).  usage: python label_conflict.py"""
import numpy as np
from common import *
d = np.load(os.path.join(ART, "cic.npz"), allow_pickle=True)
Xte, lte = d["Xte"], d["lte"]
Xb = np.concatenate([d["Xfit"][d["lfit"] == "BENIGN"], d["Xcal"], d["Xtune"][d["ltune"] == "BENIGN"]])
Xa = np.concatenate([d["Xfit"][d["lfit"] != "BENIGN"], d["Xtune"][d["ltune"] != "BENIGN"]])
E = np.load(os.path.join(ART, "evid_cic.npz"), allow_pickle=True)["E"]
dec = np.where(E >= 1e3, 2, np.where(E >= 1e2, 1, 0))
row = lambda x: bytes(np.ascontiguousarray(x.astype(np.float32)).view(np.uint8))
keys = lambda X: {row(x) for x in X}
kb, ka = keys(Xb), keys(Xa)
out = {}
for c in ["BOT", "DDOS", "PORTSCAN"]:
    m = np.where(lte == c)[0]
    dup = np.array([row(Xte[i]) in kb for i in m]); miss = dec[m] == 0
    out[c] = dict(n=int(len(m)), dup_of_benign=int(dup.sum()), missed=int(miss.sum()),
                  missed_and_dup=int((miss & dup).sum()))
mb = np.where((lte == "BENIGN") & (dec >= 1))[0]
out["BENIGN_flagged"] = dict(n=int(len(mb)), dup_of_attack=int(sum(row(Xte[i]) in ka for i in mb)))
print(out); save_json(out, "label_conflict_cic.json")
