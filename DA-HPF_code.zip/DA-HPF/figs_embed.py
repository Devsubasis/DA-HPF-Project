"""2D/3D scatter visualizations: PCA by class, PCA coloured by fused evidence with decision
contours, PCA decision regions with errors ringed, 3D PC1-PC2-log10E with threshold planes,
t-SNE, 3D scatter of member p-values."""
import numpy as np
from scipy.ndimage import gaussian_filter
from common import *
plt = style()
from mpl_toolkits.mplot3d import Axes3D  # noqa

DS = {"cic": "CICIDS2017", "unsw": "UNSW-NB15"}
ALPHA = {"cic": 1e-3, "unsw": 1e-2}
UNSW_COL = {"BENIGN": "#9AA0A6", "GENERIC": C["blue"], "EXPLOITS": C["orange"], "FUZZERS": C["green"],
            "DOS": C["pink"], "RECONNAISSANCE": C["sky"], "ANALYSIS": "#8C564B", "BACKDOOR": "#E15759",
            "SHELLCODE": "#B07AA1", "WORMS": C["verm"]}
MARK = {"BENIGN": "o", "DDOS": "^", "PORTSCAN": "s", "BOT": "D", "GENERIC": "^", "EXPLOITS": "s",
        "FUZZERS": "v", "DOS": "P", "RECONNAISSANCE": "X", "ANALYSIS": "<", "BACKDOOR": ">", "SHELLCODE": "h", "WORMS": "D"}
emb = {t: np.load(os.path.join(ART, f"embed_{t}.npz"), allow_pickle=True) for t in DS}
core = {t: load_json(f"core_{t}.json") for t in DS}


def cmap_for(t): return CLS_COL if t == "cic" else UNSW_COL


def nice(c): return {"DDOS": "DDoS", "PORTSCAN": "PortScan", "DOS": "DoS"}.get(c, c.title())


def subsample(lab, rng, per):
    return np.concatenate([rng.choice(np.where(lab == c)[0], min(per, int((lab == c).sum())), replace=False)
                           for c in np.unique(lab)])


# ---------------------------------------------------------- (1) PCA by class
fig, axs = plt.subplots(1, 2, figsize=(7.0, 3.1))
for j, t in enumerate(DS):
    e = emb[t]; Z, lab, evr = e["Z"], e["lab"], e["evr"]; ax = axs[j]
    rng = np.random.RandomState(0); ii = subsample(lab, rng, 1200 if t == "cic" else 500)
    order = ["BENIGN"] + [c for c in np.unique(lab) if c != "BENIGN"]
    for c in order:
        m = ii[lab[ii] == c]
        ax.scatter(Z[m, 0], Z[m, 1], s=4 if c != "BENIGN" else 3, marker=MARK.get(c, "o"), color=cmap_for(t)[c],
                   alpha=0.55 if c == "BENIGN" else 0.75, linewidths=0, label=nice(c), rasterized=True)
    ax.set_xlabel(f"PC1 ({evr[0]*100:.1f}% var.)"); ax.set_ylabel(f"PC2 ({evr[1]*100:.1f}% var.)")
    ax.set_title(f"({'ab'[j]}) {DS[t]}: 2D PCA by traffic class")
    ax.legend(fontsize=5.8, markerscale=2.2, ncol=1 if t == "cic" else 2, loc="best", handletextpad=0.2)
fig.tight_layout(); savefig(fig, "N11_PCA2D_by_class")

# ---------------------------------------------------------- (2) PCA coloured by evidence + decision contours
fig, axs = plt.subplots(1, 2, figsize=(7.0, 3.1))
for j, t in enumerate(DS):
    e = emb[t]; Z, E, lab = e["Z"], e["E"], e["lab"]; ax = axs[j]
    le = np.log10(E); a = ALPHA[t]
    o = np.argsort(le)
    sc = ax.scatter(Z[o, 0], Z[o, 1], c=le[o], s=3, cmap="viridis", linewidths=0, rasterized=True,
                    vmin=le.min(), vmax=np.log10(core[t]["E_max"]))
    cb = fig.colorbar(sc, ax=ax, fraction=0.045, pad=0.02); cb.set_label(r"$\log_{10} E(\mathbf{z})$", fontsize=7)
    cb.ax.tick_params(labelsize=6)
    for lv, nm, col in [(np.log10(1 / a), "DROP", C["verm"]), (np.log10(1 / (10 * a)), "MONITOR", "k")]:
        cb.ax.axhline(lv, color=col, lw=1.4); cb.ax.text(-0.15, lv, nm, transform=cb.ax.get_yaxis_transform(), ha="right",
                                                         va="center", fontsize=5.5, color=col)
    ax.set_xlabel("PC1"); ax.set_ylabel("PC2"); ax.set_title(f"({'ab'[j]}) {DS[t]}: fused evidence $E(\\mathbf{{z}})$ over the PCA plane")
fig.tight_layout(); savefig(fig, "N12_PCA2D_evidence_colored")

# ---------------------------------------------------------- (3) PCA decisions with errors ringed
fig, axs = plt.subplots(1, 2, figsize=(7.0, 3.1))
dcol = {0: "#9AA0A6", 1: C["orange"], 2: C["verm"]}; dname = {0: "ALLOW", 1: "MONITOR", 2: "DROP"}
for j, t in enumerate(DS):
    e = emb[t]; Z, dec, y = e["Z"], e["dec"], e["y"]; ax = axs[j]
    for k in [0, 1, 2]:
        m = dec == k
        ax.scatter(Z[m, 0], Z[m, 1], s=3, color=dcol[k], linewidths=0, alpha=0.7, label=f"{dname[k]} ({m.sum():,})",
                   rasterized=True)
    fp = (y == 0) & (dec >= 1); fn = (y == 1) & (dec == 0)
    ax.scatter(Z[fp, 0], Z[fp, 1], s=22, facecolors="none", edgecolors="k", linewidths=0.7, label=f"false alarm ({fp.sum()})")
    ax.scatter(Z[fn, 0], Z[fn, 1], s=22, marker="s", facecolors="none", edgecolors=C["blue"], linewidths=0.7,
               label=f"missed attack ({fn.sum()})")
    ax.set_xlabel("PC1"); ax.set_ylabel("PC2"); ax.set_title(f"({'ab'[j]}) {DS[t]}: triage decisions and errors")
    ax.legend(fontsize=5.8, markerscale=1.0, loc="best")
fig.text(0.5, -0.01, "Sample enriched with all flagged benign flows and up to 300 missed attacks to make errors visible.",
         ha="center", fontsize=6.5)
fig.tight_layout(); savefig(fig, "N13_PCA2D_decisions_errors")

# ---------------------------------------------------------- (4) 3D PC1-PC2-log10E with planes
fig = plt.figure(figsize=(7.0, 3.3))
for j, t in enumerate(DS):
    e = emb[t]; Z, E, lab = e["Z"], e["E"], e["lab"]; a = ALPHA[t]
    ax = fig.add_subplot(1, 2, 1 + j, projection="3d")
    rng = np.random.RandomState(2); ii = subsample(lab, rng, 700 if t == "cic" else 300)
    for c in ["BENIGN"] + [c for c in np.unique(lab) if c != "BENIGN"]:
        m = ii[lab[ii] == c]
        ax.scatter(Z[m, 0], Z[m, 1], np.log10(E[m]), s=3, color=cmap_for(t)[c], marker=MARK.get(c, "o"),
                   alpha=0.7, linewidths=0, label=nice(c), depthshade=False, rasterized=True)
    xx, yy = np.meshgrid(np.linspace(np.percentile(Z[ii, 0], 1), np.percentile(Z[ii, 0], 99), 2),
                         np.linspace(np.percentile(Z[ii, 1], 1), np.percentile(Z[ii, 1], 99), 2))
    ax.plot_surface(xx, yy, np.full_like(xx, np.log10(1 / a)), color=C["verm"], alpha=0.18)
    ax.plot_surface(xx, yy, np.full_like(xx, np.log10(1 / (10 * a))), color="k", alpha=0.10)
    ax.set_xlabel("PC1", labelpad=-4, fontsize=7); ax.set_ylabel("PC2", labelpad=-4, fontsize=7)
    ax.set_zlabel(r"$\log_{10}E$", labelpad=-4, fontsize=7); ax.tick_params(labelsize=5.5, pad=-2)
    ax.view_init(18, -62); ax.set_title(f"({'ab'[j]}) {DS[t]}: DROP plane $1/\\alpha$={1/a:g}, MONITOR plane {1/(10*a):g}", fontsize=7)
    ax.legend(fontsize=5, markerscale=2, loc="upper left", ncol=1 if t == "cic" else 2)
fig.tight_layout(); savefig(fig, "N14_3D_PCA_evidence_threshold_planes")

# ---------------------------------------------------------- (5) t-SNE by class and by decision
fig, axs = plt.subplots(2, 2, figsize=(7.0, 6.0))
for j, t in enumerate(DS):
    e = emb[t]; T2, ti = e["tsne"], e["ts_i"]; lab = e["lab"][ti]; dec = e["dec"][ti]
    ax = axs[0, j]
    for c in ["BENIGN"] + [c for c in np.unique(lab) if c != "BENIGN"]:
        m = lab == c
        ax.scatter(T2[m, 0], T2[m, 1], s=3, color=cmap_for(t)[c], marker=MARK.get(c, "o"), linewidths=0,
                   alpha=0.75, label=nice(c), rasterized=True)
    ax.set_title(f"({'ab'[j]}) {DS[t]}: t-SNE by class"); ax.set_xticks([]); ax.set_yticks([])
    ax.legend(fontsize=5.5, markerscale=2, ncol=1 if t == "cic" else 2, loc="best")
    ax = axs[1, j]
    for k in [0, 1, 2]:
        m = dec == k; ax.scatter(T2[m, 0], T2[m, 1], s=3, color=dcol[k], linewidths=0, alpha=0.75,
                                 label=dname[k], rasterized=True)
    ax.set_title(f"({'cd'[j]}) {DS[t]}: t-SNE by DA-HPF decision"); ax.set_xticks([]); ax.set_yticks([])
    ax.legend(fontsize=6, markerscale=2)
fig.tight_layout(); savefig(fig, "N15_tSNE_class_and_decision")

# ---------------------------------------------------------- (6) 3D scatter of member conformal p-values
ev = np.load(os.path.join(ART, "evid_cic.npz"), allow_pickle=True)
U, lab = ev["U"], ev["lte"]; rng = np.random.RandomState(4); ii = subsample(lab, rng, 900)
fig = plt.figure(figsize=(3.6, 3.3)); ax = fig.add_subplot(111, projection="3d")
for c in ["BENIGN", "DDOS", "PORTSCAN", "BOT"]:
    m = ii[lab[ii] == c]; jit = rng.normal(0, 0.03, (len(m), 3))
    ax.scatter(-np.log10(U[m, 1]) + jit[:, 0], -np.log10(U[m, 2]) + jit[:, 1], -np.log10(U[m, 3]) + jit[:, 2],
               s=3, color=CLS_COL[c], marker=MARK[c], alpha=0.65, linewidths=0, label=nice(c), depthshade=False)
ax.set_xlabel(r"$-\log_{10}u_{\mathrm{XGB}}$", labelpad=-3, fontsize=7)
ax.set_ylabel(r"$-\log_{10}u_{\mathrm{LGBM}}$", labelpad=-3, fontsize=7)
ax.set_zlabel(r"$-\log_{10}u_{\mathrm{Cat}}$", labelpad=-3, fontsize=7); ax.tick_params(labelsize=6, pad=-2)
ax.view_init(20, 40); ax.legend(fontsize=6, markerscale=2, loc="upper left")
ax.set_title("CICIDS2017: member conformal p-values (3D)", fontsize=8)
fig.tight_layout(); savefig(fig, "N16_3D_member_pvalues")
print("embedding figs done")
