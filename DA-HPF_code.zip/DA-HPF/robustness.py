"""Robustness: Gaussian feature noise, missing features (imputed by the Fit mean), and
attack-prevalence changes. usage: python robustness.py TAG VARIANT"""
import sys, joblib, numpy as np
from sklearn.metrics import f1_score, matthews_corrcoef
from common import *

tag, variant = sys.argv[1], sys.argv[2]
ds = "unsw" if variant.startswith("unsw") else "cic"
alpha = 1e-3 if ds == "cic" else 1e-2
d = np.load(os.path.join(ART, f"{variant}.npz"), allow_pickle=True)
s = np.load(os.path.join(ART, f"scores_{tag}.npz"), allow_pickle=True)
core = load_json(f"core_{tag}.json"); kap, lam = core["kappa"], np.array(core["lam"])
models = joblib.load(os.path.join(ART, f"models_{tag}.joblib"))
refs = build_refs(s["S_cal"]); Sc = s["S_cal"]
thr_x = np.quantile(Sc[:, 1], 1 - alpha, method="higher"); thr_v = np.quantile(Sc.mean(1), 1 - alpha, method="higher")
rng = np.random.RandomState(11)
Xte, lte = d["Xte"], d["lte"]
idx = np.concatenate([rng.choice(np.where(lte == c)[0], min(int((lte == c).sum()), n), replace=False)
                      for c, n in zip(*np.unique(lte, return_counts=True))
                      for n in [max(2000, int(0.25 * n))]])
Xs, ls = Xte[idx], lte[idx]; y = (ls != "BENIGN").astype(int)
classes = [c for c in np.unique(ls) if c != "BENIGN"]


def evaluate(X):
    S = score_matrix(models, X.astype(np.float32))
    E = cref_E(refs, S, kap, lam)
    out = {}
    for nm, yh in [("CREF (proposed)", E >= 1 / alpha), ("XGBoost", S[:, 1] > thr_x),
                   ("Soft voting", S.mean(1) > thr_v)]:
        yh = yh.astype(int)
        out[nm] = dict(macro_f1=f1_score(y, yh, average="macro"), mcc=matthews_corrcoef(y, yh),
                       far=float(yh[y == 0].mean()), tpr=float(yh[y == 1].mean()),
                       per_class={c: float(yh[ls == c].mean()) for c in classes})
    return out


res = dict(alpha=alpha, n=len(idx), noise={}, missing={}, prevalence={})
for sg in [0.0, 0.05, 0.1, 0.2, 0.3, 0.5]:
    res["noise"][str(sg)] = evaluate(Xs + rng.normal(0, sg, Xs.shape))
    print(f"noise {sg}: " + " | ".join(f"{k} mF1={v['macro_f1']:.4f} FAR={v['far']*100:.3f}%"
                                         for k, v in res["noise"][str(sg)].items()), flush=True)
for fr in [0.0, 0.1, 0.2, 0.3, 0.4]:
    X2 = Xs.copy(); mask = rng.random_sample(X2.shape) < fr; X2[mask] = 0.0   # Fit mean in z-space
    res["missing"][str(fr)] = evaluate(X2)
    print(f"missing {fr}: " + " | ".join(f"{k} mF1={v['macro_f1']:.4f} FAR={v['far']*100:.3f}%"
                                           for k, v in res["missing"][str(fr)].items()), flush=True)
# prevalence: resample the full test set to a target attack share (benign fixed)
S = s["S_te"]; E = cref_E(refs, S, kap, lam); yall = (lte != "BENIGN").astype(int)
bi, ai = np.where(yall == 0)[0], np.where(yall == 1)[0]
for prev in [0.001, 0.01, 0.05, 0.2, 0.5]:
    rows = []
    for r in range(20):
        rr = np.random.RandomState(r)
        nb = len(bi); na = max(1, int(round(prev / (1 - prev) * nb)))
        ii = np.concatenate([bi, rr.choice(ai, na, replace=na > len(ai))])
        yy = yall[ii]
        o = {}
        for nm, yh in [("CREF (proposed)", E[ii] >= 1 / alpha), ("XGBoost", S[ii, 1] > thr_x),
                       ("Soft voting", S[ii].mean(1) > thr_v)]:
            yh = yh.astype(int); tp = int(((yh == 1) & (yy == 1)).sum()); fp = int(((yh == 1) & (yy == 0)).sum())
            o[nm] = dict(precision=tp / max(tp + fp, 1), far=fp / nb, mcc=matthews_corrcoef(yy, yh),
                         macro_f1=f1_score(yy, yh, average="macro"))
        rows.append(o)
    res["prevalence"][str(prev)] = {nm: {k: float(np.mean([r_[nm][k] for r_ in rows])) for k in rows[0][nm]}
                                    for nm in rows[0]}
    print(f"prevalence {prev}: " + " | ".join(f"{k} P={v['precision']:.4f}" for k, v in res["prevalence"][str(prev)].items()), flush=True)
save_json(res, f"robust_{tag}.json")
